# TCC Attendance Portal — System Developers & Contributors

1. ALLY ALLY — Mbeya University (MUST) — ICT — Main Developer
2. NICOLOUS YOHANA — Kampala — IT — Testing
3. YAZIDU YUSUFU — Mzumbe — ICTM — Testing
4. SALMA BURHANI — KITM — IT — Deployment and Tools
5. NICHOLAS MARTIN — CBE — IT — Deployment and Tools
6. ADIIL JUMA — Masai Utalii — ICT — Database
7. FADHILA SALUM — Mzumbe — ICTM — Database
8. HERIETH MHINA — Mzumbe — IT — Deployment and Tools
9. OMARY JUMA — KITM — IT — Code
