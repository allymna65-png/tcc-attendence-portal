# TCC Attendance Portal V35 — Final Production Audit

This package is the audited continuation of V34.

## Included
- React/Vite/Tailwind client
- Supabase PostgreSQL migrations and RLS
- Supabase Edge Functions
- HR Admin one-time bootstrap
- Universal authentication and forced password reset
- Field Student / Department Admin roles
- Department-scoped management
- GPS geofence with 100–500m radius options
- Sign In / Sign Out state enforcement and one-per-day constraints
- Offline attendance queue and synchronization
- Leave workflow with HR Admin and Department Admin review
- Password reset approval queue including Department Admin default password
- Notifications
- Attendance history and reporting
- CSV/XLSX import
- PWA installation support
- Developer credits

## V35 fixes
1. Department Admins can review leave requests for their own department only.
2. Leave RLS now enforces the same department boundary.
3. Department Admin password-reset approval correctly recognizes `ADM_123456` as its temporary password when applicable.
4. Attendance reports/history display user-facing `Sign In` / `Sign Out` labels instead of raw database enum names.
5. Added migration `005_department_admin_leave_rls.sql`.

## Important deployment note
The ZIP intentionally does not contain production Supabase secrets. Configure the client environment values and deploy the Supabase Edge Functions to the target Supabase project before production use.


## V36 Identity Model Update
- Portal member model is Field Student only; Staff category removed.
- Student IDs are generated automatically as `STD/YYYY/XXXX`.
- HR Admin and Department Admin IDs are generated automatically as `ADMN/YYYY/XXXX`.
- `XXXX` is random and non-sequential.
