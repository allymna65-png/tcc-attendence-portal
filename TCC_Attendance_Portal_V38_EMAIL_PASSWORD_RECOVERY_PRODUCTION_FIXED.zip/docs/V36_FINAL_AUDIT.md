# TCC Attendance Portal V36 — Final Scope Audit

## Identity
- Field Student IDs are automatic: `STD/YYYY/XXXX`.
- HR Admin and Department Admin IDs are automatic: `ADMN/YYYY/XXXX`.
- `XXXX` is random/non-sequential and unique.
- IDs are generated server-side by the database trigger; users do not type them.

## Portal Scope
- The operational member category is Field Student only.
- Staff onboarding, Staff category selectors, Staff reports and Staff default passwords are removed.
- Administrators remain separate management accounts.

## Onboarding
- Add Field Student requires Full Name, Department and Official Email only.
- Excel/CSV import requires no Student ID and no category; the system assigns Field Student and generates the ID.
- Department Admin registration requires no Admin ID; the system generates it.
- Primary HR Admin bootstrap receives an automatically generated Admin ID.
