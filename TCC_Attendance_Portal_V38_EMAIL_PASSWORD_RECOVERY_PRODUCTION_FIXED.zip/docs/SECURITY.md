# Security Notes

1. The browser uses only the Supabase publishable key.
2. Service role key is used only by Edge Functions.
3. RLS protects user/profile/leave/reset/audit reads.
4. Attendance inserts are blocked for ordinary authenticated browser clients and occur through the attendance Edge Function.
5. Geofence is calculated server-side with Haversine.
6. GPS accuracy is validated server-side.
7. The server re-checks the daily state machine, so client-side buttons are not trusted.
8. Client event IDs make offline synchronization idempotent.
9. Device fingerprint is stored and checked for the current day's session. This is a practical browser-device lock, not a cryptographic proof of physical identity.
10. Browser offline storage is device-local. When connectivity returns, queued events are submitted to the server and revalidated.
