import { createClient } from "@supabase/supabase-js";

const SUPABASE_URL =
  import.meta.env.VITE_SUPABASE_URL ||
  "https://qjnkjifgchbnvhxnpegd.supabase.co";

const SUPABASE_PUBLISHABLE_KEY =
  import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY ||
  "sb_publishable_Dw6TVVhbRGAQRORKm-h62Q_DTcVF8hH";

if (!SUPABASE_URL || !SUPABASE_PUBLISHABLE_KEY) {
  throw new Error("Supabase configuration is missing.");
}

export const supabase = createClient(
  SUPABASE_URL,
  SUPABASE_PUBLISHABLE_KEY,
  {
    auth: {
      // Keep authentication only for the current browser/app tab.
      // Closing the app/tab clears the session, so the next launch requires login again.
      persistSession: true,
      storage: typeof window !== "undefined" ? window.sessionStorage : undefined,
      autoRefreshToken: true,
      detectSessionInUrl: true
    }
  }
);
