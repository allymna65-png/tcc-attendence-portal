import React,{useEffect,useState} from "react";
import {createRoot} from "react-dom/client";
import {supabase} from "./supabase";
import {setupRequired,currentProfile,cachedProfile,cachedSetup} from "./lib/api";
import AuthShell from "./components/AuthShell";
import {Setup,Login,Forgot,ResetPassword,ForceReset} from "./pages/AuthPages";
import FieldStudentPortal from "./pages/StaffPortal";
import AdminDashboard from "./pages/AdminDashboard";
import "./index.css";

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { error: null };
  }
  static getDerivedStateFromError(error) {
    return { error };
  }
  render() {
    if (this.state.error) {
      return (
        <div style={{minHeight:"100vh",display:"grid",placeItems:"center",padding:"24px",background:"#f1f5f9",fontFamily:"system-ui"}}>
          <div style={{maxWidth:"680px",background:"#fff",border:"1px solid #e2e8f0",borderRadius:"20px",padding:"28px",boxShadow:"0 15px 40px rgba(15,23,42,.12)"}}>
            <h1 style={{margin:"0 0 8px",fontSize:"24px",fontWeight:800,color:"#0f172a"}}>TCC Attendance</h1>
            <p style={{margin:"0 0 16px",color:"#64748b"}}>The application encountered an error.</p>
            <pre style={{whiteSpace:"pre-wrap",fontSize:"13px",color:"#991b1b",background:"#fef2f2",padding:"14px",borderRadius:"12px"}}>{String(this.state.error?.message || this.state.error)}</pre>
            <button onClick={() => location.reload()} style={{marginTop:"16px",background:"#0b1f3a",color:"#fff",border:0,borderRadius:"12px",padding:"12px 18px",fontWeight:700}}>Reload</button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function App(){
 const[user,setUser]=useState(null),[setup,setSetup]=useState(null),[screen,setScreen]=useState(()=>window.location.pathname==="/reset-password"?"reset-password":"login"),[bootError,setBootError]=useState("");
 useEffect(()=>{(async()=>{
  const cachedP=cachedProfile();
  const cachedS=cachedSetup();
  try{
   const {data:{session}}=await supabase.auth.getSession();
   if(session){
    if(cachedP)setUser(cachedP);
    if(!navigator.onLine){if(cachedP){setSetup(false);return}throw new Error("Offline session data is not available on this device.")}
    try{const p=await currentProfile();if(p)setUser(p)}catch(e){if(cachedP){setSetup(false);return}throw e}
    setSetup(false);
    return;
   }
   if(!navigator.onLine){setSetup(cachedS===true);return}
   const s=await setupRequired();
   setSetup(s);
  }catch(e){
   if(!navigator.onLine&&cachedP){setUser(cachedP);setSetup(false);return}
   setBootError(e.message);setSetup(false);
  }
 })();
  const{data:{subscription}}=supabase.auth.onAuthStateChange(async(event,session)=>{
   if(event==="PASSWORD_RECOVERY"){setScreen("reset-password");return}
   if(session){try{const p=await currentProfile();setUser(p)}catch{const p=cachedProfile();if(p)setUser(p)}}else {setUser(null);if(window.location.pathname!=="/reset-password")setScreen("login")}
  });
  return()=>subscription.unsubscribe()
 },[]);
 async function logout(){await supabase.auth.signOut();setUser(null);setScreen("login")}
 if(bootError)return <AuthShell title="Configuration Error" subtitle="TCC Attendance Portal"><div className="rounded-xl bg-red-50 p-4 text-sm text-red-700">{bootError}</div></AuthShell>;
 if(setup===null)return <div className="grid min-h-screen place-items-center bg-slate-100 text-slate-500">Loading TCC Attendance…</div>;
 if(!user&&setup)return <Setup onDone={setUser}/>;
 if(screen==="reset-password")return <ResetPassword onDone={(p)=>{setUser(p);window.history.replaceState({},"", "/");setScreen("login")}} onBack={()=>{window.history.replaceState({},"", "/");setScreen("login")}}/>;
 if(!user&&screen==="forgot")return <Forgot onBack={()=>setScreen("login")}/>;
 if(!user)return <Login onLogin={setUser} onForgot={()=>setScreen("forgot")}/>;
 if(user.must_reset_password)return <ForceReset user={user} onDone={setUser}/>;
 if(user.category==="HR_ADMIN"||user.category==="DEPARTMENT_ADMIN")return <AdminDashboard user={user} onLogout={logout}/>;
 return <FieldStudentPortal user={user} onLogout={logout}/>;
}
createRoot(document.getElementById("root")).render(<ErrorBoundary><App/></ErrorBoundary>);

if ("serviceWorker" in navigator) window.addEventListener("load",()=>navigator.serviceWorker.register("/sw-v38.js").catch(()=>{}));
