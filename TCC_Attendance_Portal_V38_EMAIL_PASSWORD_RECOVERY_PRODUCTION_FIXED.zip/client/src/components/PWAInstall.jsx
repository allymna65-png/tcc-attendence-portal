import React,{useEffect,useState} from "react";
import {Download, Smartphone} from "lucide-react";
import {Button} from "./UI";

export default function PWAInstall(){
 const[prompt,setPrompt]=useState(null),[installed,setInstalled]=useState(false),[message,setMessage]=useState("");
 useEffect(()=>{
  const onBeforeInstall=e=>{e.preventDefault();setPrompt(e)};
  const onInstalled=()=>{setInstalled(true);setPrompt(null);setMessage("")};
  window.addEventListener("beforeinstallprompt",onBeforeInstall);
  window.addEventListener("appinstalled",onInstalled);
  if(window.matchMedia("(display-mode: standalone)").matches||window.navigator.standalone)setInstalled(true);
  return()=>{window.removeEventListener("beforeinstallprompt",onBeforeInstall);window.removeEventListener("appinstalled",onInstalled)}
 },[]);
 async function install(){
  setMessage("");
  if(prompt){
   await prompt.prompt();
   const result=await prompt.userChoice;
   if(result.outcome!=="accepted")setMessage("Installation was cancelled.");
   setPrompt(null);
   return;
  }
  if(/iphone|ipad|ipod/i.test(navigator.userAgent)){
   setMessage("Use Share, then Add to Home Screen.");
   return;
  }
  setMessage("Open the browser menu and select Install App or Add to Home Screen.");
 }
 if(installed)return null;
 return <div className="relative">
  <Button variant="outline" onClick={install}><Download size={16}/> Install App</Button>
  {message&&<div className="absolute right-0 top-full z-50 mt-2 w-72 rounded-xl border border-slate-200 bg-white p-3 text-xs text-slate-600 shadow-xl">{message}</div>}
 </div>;
}
