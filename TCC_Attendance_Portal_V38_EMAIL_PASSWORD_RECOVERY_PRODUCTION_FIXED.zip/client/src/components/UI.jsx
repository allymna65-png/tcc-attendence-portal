import React from "react";
import { X } from "lucide-react";
import { passwordScore } from "../lib/security";

export function Button({children,className="",variant="primary",...p}){
  const styles={
    primary:"bg-[#0b1f3a] text-white hover:bg-[#102b50]",
    success:"bg-emerald-600 text-white hover:bg-emerald-700",
    warning:"bg-amber-500 text-white hover:bg-amber-600",
    danger:"bg-red-600 text-white hover:bg-red-700",
    ghost:"bg-slate-100 text-slate-800 hover:bg-slate-200",
    outline:"border border-slate-300 bg-white text-slate-800 hover:bg-slate-50"
  };
  return <button {...p} className={`inline-flex items-center justify-center gap-2 min-h-10 rounded-xl px-3 py-2 text-sm font-bold transition sm:px-4 disabled:opacity-50 ${styles[variant]} ${className}`}>{children}</button>
}
export function Card({children,className=""}){return <div className={`rounded-2xl border border-slate-200 bg-white shadow-sm ${className}`}>{children}</div>}
export function Input({label,...p}){return <label className="block"><span className="mb-1.5 block text-xs font-bold uppercase tracking-wide text-slate-500">{label}</span><input {...p} className="w-full rounded-xl border border-slate-300 px-3 py-2.5 sm:px-3.5 sm:py-3 outline-none focus:border-blue-700 focus:ring-2 focus:ring-blue-100"/></label>}
export function Select({label,children,...p}){return <label className="block"><span className="mb-1.5 block text-xs font-bold uppercase tracking-wide text-slate-500">{label}</span><select {...p} className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2.5 sm:px-3.5 sm:py-3">{children}</select></label>}
export function Textarea({label,...p}){return <label className="block"><span className="mb-1.5 block text-xs font-bold uppercase tracking-wide text-slate-500">{label}</span><textarea {...p} className="min-h-28 w-full rounded-xl border border-slate-300 px-3 py-2.5 sm:px-3.5 sm:py-3 outline-none focus:border-blue-700 focus:ring-2 focus:ring-blue-100"/></label>}
export function Badge({children,tone="slate"}){const m={green:"bg-emerald-50 text-emerald-700",amber:"bg-amber-50 text-amber-700",red:"bg-red-50 text-red-700",blue:"bg-blue-50 text-blue-700",slate:"bg-slate-100 text-slate-700"};return <span className={`inline-flex rounded-full px-2.5 py-1 text-xs font-bold ${m[tone]||m.slate}`}>{children}</span>}
export function PasswordMeter({password}){const n=passwordScore(password);return <div><div className="grid grid-cols-5 gap-1.5">{[1,2,3,4,5].map(i=><div key={i} className={`h-2 rounded-full ${i<=n?"bg-emerald-500":"bg-slate-200"}`}/>)}</div><p className="mt-2 text-xs text-slate-500">{n===5?"Very strong":"Requires 8+ chars, uppercase, lowercase, number and special character"}</p></div>}
export function Modal({title,onClose,children}){return <div className="fixed inset-0 z-[1000] flex items-center justify-center bg-slate-950/60 p-4"><div className="max-h-[92vh] w-full max-w-2xl overflow-auto rounded-2xl bg-white p-6 shadow-2xl"><div className="mb-5 flex items-center justify-between"><h2 className="text-lg font-black">{title}</h2><button onClick={onClose} className="rounded-lg p-2 hover:bg-slate-100"><X/></button></div>{children}</div></div>}
export function Stat({label,value,icon,tone="blue"}){return <Card className="p-5"><div className="flex items-start justify-between"><div><p className="text-xs font-bold uppercase tracking-wide text-slate-500">{label}</p><p className="mt-2 text-3xl font-black">{value}</p></div><div className={`rounded-xl p-3 ${tone==="green"?"bg-emerald-50 text-emerald-700":tone==="amber"?"bg-amber-50 text-amber-700":"bg-blue-50 text-blue-700"}`}>{icon}</div></div></Card>}

export function ProfileModal({user,onClose}){
  const role=user?.category==="HR_ADMIN"?"HR Admin":user?.category==="DEPARTMENT_ADMIN"?"Department Admin":"Field Student";
  const initials=(user?.full_name||"U").split(/\s+/).filter(Boolean).slice(0,2).map(x=>x[0]).join("").toUpperCase();
  const Item=({label,value})=><div className="rounded-2xl border border-slate-200 bg-white p-4"><div className="text-[11px] font-black uppercase tracking-wide text-slate-400">{label}</div><div className="mt-1 break-words font-bold text-slate-800">{value||"—"}</div></div>;
  return <Modal title="My Profile" onClose={onClose}>
    <div className="space-y-4">
      <div className="flex items-center gap-4 rounded-2xl bg-slate-50 p-4">
        <div className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-[#0b1f3a] text-lg font-black text-white">{initials}</div>
        <div className="min-w-0">
          <h2 className="truncate text-lg font-black text-slate-900">{user?.full_name||"—"}</h2>
          <p className="text-sm text-slate-500">{role}</p>
          <p className="text-xs text-slate-400">{user?.user_code||"—"}</p>
        </div>
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <Item label="Name" value={user?.full_name}/>
        <Item label="Email" value={user?.official_email}/>
        <Item label="Phone Number" value={user?.phone}/>
        <Item label="Department Name" value={user?.department}/>
        <Item label="Position / Role" value={role}/>
        <Item label="ID" value={user?.user_code}/>
      </div>
      <div className="rounded-2xl bg-emerald-50 p-4 text-sm text-emerald-800">Your profile information is managed by the HR Administration.</div>
    </div>
  </Modal>
}
