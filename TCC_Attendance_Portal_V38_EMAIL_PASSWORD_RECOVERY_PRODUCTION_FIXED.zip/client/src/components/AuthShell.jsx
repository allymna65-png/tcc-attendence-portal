import React from "react";
import { ShieldCheck, MapPin, WifiOff, Clock3 } from "lucide-react";
import PWAInstall from "./PWAInstall";

export default function AuthShell({title, subtitle, children}) {
  return (
    <main className="tcc-grid relative min-h-screen overflow-hidden bg-slate-100">
      <div className="absolute right-4 top-4 z-50"><PWAInstall/></div>
      <div className="pointer-events-none absolute -left-24 -top-24 h-72 w-72 rounded-full bg-blue-600/15 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-32 -right-20 h-96 w-96 rounded-full bg-emerald-500/10 blur-3xl" />

      <div className="relative mx-auto flex min-h-screen w-full max-w-7xl items-center justify-center p-4 sm:p-6 lg:p-10">
        <div className="grid w-full max-w-5xl overflow-hidden rounded-[28px] border border-white/70 bg-white shadow-soft lg:grid-cols-[1.02fr_.98fr]">
          <section className="relative hidden overflow-hidden bg-gradient-to-br from-[#06172f] via-[#0b2850] to-[#083b4a] p-8 text-white lg:flex lg:flex-col lg:justify-between xl:p-12">
            <div className="absolute -right-20 -top-20 h-64 w-64 rounded-full border-[40px] border-emerald-400/10" />
            <div className="absolute -bottom-24 -left-20 h-72 w-72 rounded-full border-[55px] border-blue-400/10" />

            <div className="relative">
              <div className="mb-10 flex items-center gap-3">
                <div className="grid h-12 w-12 place-items-center rounded-2xl bg-white p-1 ring-1 ring-white/20">
                  <img src="/icons/tcc-logo.png" alt="Tanga City Council" className="h-full w-full rounded-xl object-contain" />
                </div>
                <div>
                  <div className="text-xl font-black tracking-tight">TCC <span className="text-emerald-300">ATTENDANCE</span></div>
                                  </div>
              </div>

              <span className="inline-flex rounded-full bg-emerald-400/10 px-3 py-1.5 text-xs font-bold text-emerald-200 ring-1 ring-emerald-300/20">
                TCC Attendance
              </span>
              <h2 className="mt-5 max-w-lg text-4xl font-black leading-tight xl:text-5xl">
                Secure attendance for a connected workforce.
              </h2>
              <p className="mt-5 max-w-lg text-sm leading-7 text-slate-300">
                GPS-verified attendance, offline synchronization, leave workflows and HR reporting for Field Students.
              </p>

              <div className="mt-9 grid gap-3">
                {[
                  [MapPin, "GPS geofencing", "100m · 200m · 300m · 400m · 500m"],
                  [WifiOff, "Offline ready", "Sync automatically when online"],
                  [Clock3, "Smart time rules", "07:30 On Time threshold"],
                ].map(([Icon, label, text]) => (
                  <div key={label} className="flex items-center gap-3 rounded-2xl bg-white/7 p-3 ring-1 ring-white/10">
                    <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-white/10">
                      <Icon className="h-5 w-5 text-emerald-300" />
                    </div>
                    <div>
                      <p className="text-sm font-bold">{label}</p>
                      <p className="text-xs text-slate-400">{text}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="relative mt-10 flex items-center justify-between border-t border-white/10 pt-5 text-xs text-slate-400">
              <span>TCC Attendance</span>
              <span className="font-semibold text-emerald-300">Secure • Auditable</span>
            </div>
          </section>

          <section className="p-5 sm:p-8 lg:p-10 xl:p-12">
            <div className="mb-8 flex items-center gap-3 lg:hidden">
              <div className="grid h-11 w-11 place-items-center rounded-2xl bg-white p-1 shadow-lg">
                <img src="/icons/tcc-logo.png" alt="Tanga City Council" className="h-full w-full rounded-xl object-contain" />
              </div>
              <div>
                <div className="text-lg font-black text-slate-900">TCC <span className="text-emerald-600">ATTENDANCE</span></div>
                              </div>
            </div>

            <div className="mb-7">
              <div className="mb-2 text-[11px] font-black uppercase tracking-[.22em] text-blue-700">TCC Attendance</div>
              <h1 className="text-3xl font-black tracking-tight text-slate-950 sm:text-4xl">{title}</h1>
              {subtitle ? <p className="mt-2 max-w-xl text-sm leading-6 text-slate-500">{subtitle}</p> : null}
            </div>

            {children}
          </section>
        </div>
      </div>
    </main>
  );
}
