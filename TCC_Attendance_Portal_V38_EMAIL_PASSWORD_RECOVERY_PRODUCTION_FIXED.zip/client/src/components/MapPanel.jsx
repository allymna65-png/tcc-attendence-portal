import React,{useEffect,useState} from "react";
import {MapContainer,TileLayer,Marker,Circle,Popup} from "react-leaflet";
import L from "leaflet";
import {Card} from "./UI";
import {supabase} from "../supabase";
import {getBestPosition} from "../lib/gps";

const icon=L.divIcon({className:"",html:'<div style="width:18px;height:18px;border-radius:50%;background:#0b1f3a;border:3px solid white;box-shadow:0 1px 8px #000"></div>'});

export default function MapPanel(){
 const[radius,setRadius]=useState(100),[center,setCenter]=useState(null),[pos,setPos]=useState(null);
 useEffect(()=>{let alive=true;supabase.from("app_settings").select("geofence_radius_m,hq_lat,hq_lng").single().then(({data})=>{if(alive&&data){setRadius(data.geofence_radius_m);setCenter([data.hq_lat,data.hq_lng])}});getBestPosition().then(p=>{if(alive&&p?.coords)setPos([p.coords.latitude,p.coords.longitude])}).catch(()=>{});return()=>{alive=false}},[]);
 return <Card className="overflow-hidden"><div className="border-b p-4"><h2 className="font-black">Attendance Area</h2><p className="text-xs text-slate-500">Radius {radius}m · Live device location</p></div><div className="h-72">{center&&<MapContainer center={center} zoom={17} scrollWheelZoom={false}><TileLayer attribution='&copy; OpenStreetMap contributors' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"/><Marker position={center} icon={icon}><Popup>Center</Popup></Marker><Circle center={center} radius={radius} pathOptions={{color:"#10b981",fillOpacity:.12}}/>{pos&&<Marker position={pos}><Popup>Current location</Popup></Marker>}</MapContainer>}</div></Card>
}
