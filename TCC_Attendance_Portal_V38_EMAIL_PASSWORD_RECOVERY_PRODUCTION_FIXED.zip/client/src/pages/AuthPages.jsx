import React,{useState} from "react";
import AuthShell from "../components/AuthShell";
import {Button,Input,PasswordMeter} from "../components/UI";
import {supabase} from "../supabase";
import {passwordValid} from "../lib/security";
import {invoke} from "../lib/api";

export function Setup({onDone}){
 const [f,setF]=useState({fullName:"",email:"",phone:"",password:""}),[msg,setMsg]=useState(""),[busy,setBusy]=useState(false);
 async function submit(e){e.preventDefault();setMsg("");if(!passwordValid(f.password))return setMsg("Password does not meet all strength requirements.");setBusy(true);
  try{const r=await invoke("bootstrap-admin",{full_name:f.fullName,official_email:f.email,phone:f.phone,password:f.password});
    const {data,error}=await supabase.auth.signInWithPassword({email:f.email,password:f.password}); if(error) throw error; onDone(r.profile);
  }catch(e){setMsg(e.message)}finally{setBusy(false)}
 }
 return <AuthShell title="Initial Setup: Create Primary HR Admin" subtitle="One-time bootstrapping. Public admin self-registration disappears after the first admin.">
  <form onSubmit={submit} className="space-y-4"><Input label="Full Name" required value={f.fullName} onChange={e=>setF({...f,fullName:e.target.value})}/><Input label="Official Email" type="email" required value={f.email} onChange={e=>setF({...f,email:e.target.value})}/><Input label="Phone Number" required value={f.phone} onChange={e=>setF({...f,phone:e.target.value})}/><Input label="Password" type="password" required value={f.password} onChange={e=>setF({...f,password:e.target.value})}/><PasswordMeter password={f.password}/>{msg&&<div className="rounded-xl bg-red-50 p-3 text-sm text-red-700">{msg}</div>}<Button disabled={busy} className="w-full">{busy?"Creating…":"Create Primary HR Admin"}</Button></form>
 </AuthShell>
}

export function Login({onLogin,onForgot}){
 const[id,setId]=useState(""),[password,setPassword]=useState(""),[msg,setMsg]=useState(""),[busy,setBusy]=useState(false);
 async function submit(e){e.preventDefault();setMsg("");setBusy(true);try{let email=id.trim();if(!email.includes("@")){const{data,error}=await supabase.from("profiles").select("official_email").eq("user_code",email).maybeSingle();if(error||!data?.official_email)throw new Error("Invalid Email / ID.");email=data.official_email}
  const{data,error}=await supabase.auth.signInWithPassword({email,password});if(error)throw error;
  const{data:profile,error:pe}=await supabase.from("profiles").select("*").eq("id",data.user.id).single();if(pe)throw pe;if(!profile.is_active)throw new Error("This account is disabled.");
  onLogin(profile);
 }catch(e){setMsg(e.message)}finally{setBusy(false)}}
 return <AuthShell title="Universal Login" subtitle="">
  <form onSubmit={submit} className="space-y-4"><Input label="Email / ID" required value={id} onChange={e=>setId(e.target.value)} placeholder="name@council.go.tz or STD/2026/AB12"/><Input label="Password" type="password" required value={password} onChange={e=>setPassword(e.target.value)}/>{msg&&<div className="rounded-xl bg-red-50 p-3 text-sm text-red-700">{msg}</div>}<Button disabled={busy} className="w-full">{busy?"Signing in…":"Sign In"}</Button><button type="button" onClick={onForgot} className="w-full text-sm font-bold text-blue-700 hover:underline">Forgot Password?</button></form>
 </AuthShell>
}

export function Forgot({onBack}){
 const[email,setEmail]=useState(""),[msg,setMsg]=useState(""),[done,setDone]=useState(false),[busy,setBusy]=useState(false);
 async function submit(e){
  e.preventDefault();
  if(busy||done)return;
  setMsg("");
  const value=email.trim().toLowerCase();
  if(!value)return setMsg("Official email is required.");
  setBusy(true);
  try{
   const redirectTo="https://tccattendanceportalv37emailpassword-tan.vercel.app/reset-password";
   const {error}=await supabase.auth.resetPasswordForEmail(value,{redirectTo});
   if(error){
    const status=error.status;
    const raw=String(error.message||"");
    if(status===429||/rate.?limit|too many|exceed/i.test(raw)){
      throw new Error("Too many reset requests were made recently. Please wait before requesting another reset email.");
    }
    throw error;
   }
   setDone(true);
   setMsg("If this email belongs to a registered account, a password reset link has been sent. Check your inbox and spam folder.");
  }catch(e){
   setMsg(e.message||"Unable to send the reset email.");
  }finally{
   setBusy(false);
  }
 }
 return <AuthShell title="Forgot Password" subtitle="Reset your password securely using your registered official email.">
  <form onSubmit={submit} className="space-y-4" noValidate><Input label="Official Email" type="email" required value={email} onChange={e=>{setEmail(e.target.value);setMsg("");setDone(false)}} placeholder="name@council.go.tz"/>
  {msg&&<div className={`rounded-xl p-3 text-sm ${done?"bg-emerald-50 text-emerald-700":"bg-red-50 text-red-700"}`}>{msg}</div>}
  <Button disabled={busy||done} className="w-full">{busy?"Sending…":done?"Reset Email Sent":"Send Reset Link"}</Button>
  <button type="button" onClick={onBack} className="w-full text-sm font-bold text-slate-600">Back to login</button></form>
 </AuthShell>
}

export function ResetPassword({onDone,onBack}){
 const[p,setP]=useState(""),[confirm,setConfirm]=useState(""),[msg,setMsg]=useState(""),[busy,setBusy]=useState(false);
 async function submit(e){e.preventDefault();setMsg("");if(!passwordValid(p))return setMsg("Password does not meet all strength requirements.");if(p!==confirm)return setMsg("Passwords do not match.");setBusy(true);try{
   const {data:{session}}=await supabase.auth.getSession();if(!session)throw new Error("This reset link is invalid or has expired. Please request a new reset link.");
   const {error}=await supabase.auth.updateUser({password:p});if(error)throw error;
   try{await supabase.functions.invoke("complete-password-reset")}catch(_e){}
   const {data:profile,error:pe}=await supabase.from("profiles").select("*").eq("id",session.user.id).single();if(pe)throw pe;
   onDone(profile);
 }catch(e){setMsg(e.message||"Unable to update password. Please request a new reset link.")}finally{setBusy(false)}}
 return <AuthShell title="Reset Password" subtitle="Create a new secure password for your TCC Attendance account.">
  <div className="mb-5 rounded-2xl border border-blue-100 bg-blue-50 p-4 text-sm text-blue-800">Use a strong password containing uppercase, lowercase, number and special character.</div>
  <form onSubmit={submit} className="space-y-4"><Input label="New Password" type="password" required value={p} onChange={e=>setP(e.target.value)}/><PasswordMeter password={p}/><Input label="Confirm New Password" type="password" required value={confirm} onChange={e=>setConfirm(e.target.value)}/>{msg&&<div className="rounded-xl bg-red-50 p-3 text-sm text-red-700">{msg}</div>}<Button disabled={busy} variant="success" className="w-full">{busy?"Updating…":"Update Password"}</Button><button type="button" onClick={onBack} className="w-full text-sm font-bold text-slate-600">Back to login</button></form>
 </AuthShell>
}

export function ForceReset({user,onDone}){
 const[p,setP]=useState(""),[msg,setMsg]=useState(""),[busy,setBusy]=useState(false);
 async function submit(e){e.preventDefault();if(!passwordValid(p))return setMsg("Password does not meet all strength requirements.");setBusy(true);try{const{data,error}=await supabase.auth.updateUser({password:p});if(error)throw error;const{data:resetDone,error:re}=await supabase.functions.invoke("complete-password-reset");if(re)throw re;if(!resetDone?.ok)throw new Error("Password was changed, but your profile could not be updated. Contact HR Admin.");const{data:profile,error:pe}=await supabase.from("profiles").select("*").eq("id",user.id).single();if(pe)throw pe;onDone(profile)}catch(e){setMsg(e.message)}finally{setBusy(false)}}
 return <AuthShell title="Mandatory Password Reset" subtitle="Your temporary password must be replaced before continuing."><p className="mb-5 text-sm text-slate-600">Welcome <b>{user.full_name}</b>. Choose a strong password.</p><form onSubmit={submit} className="space-y-4"><Input label="New Password" type="password" required value={p} onChange={e=>setP(e.target.value)}/><PasswordMeter password={p}/>{msg&&<div className="rounded-xl bg-red-50 p-3 text-sm text-red-700">{msg}</div>}<Button disabled={busy} variant="success" className="w-full">{busy?"Updating…":"Update Password"}</Button></form></AuthShell>
}
