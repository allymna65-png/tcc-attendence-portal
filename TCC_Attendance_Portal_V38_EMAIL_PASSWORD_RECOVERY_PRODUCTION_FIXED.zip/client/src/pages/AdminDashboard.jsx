import React,{useEffect,useMemo,useRef,useState} from "react";
import {Activity,Users,Clock3,AlertTriangle,Download,UserPlus,FileUp,Settings as SettingsIcon,LogOut,CheckCircle2,XCircle,MapPin,Navigation,Building2,ShieldCheck,Bell,CheckCheck,UserRound,KeyRound,Loader2,AlertCircle} from "lucide-react";
import {BarChart,Bar,XAxis,YAxis,CartesianGrid,Tooltip,ResponsiveContainer,LineChart,Line} from "recharts";
import * as XLSX from "xlsx";
import {supabase} from "../supabase";
import {invoke} from "../lib/api";
import {csvDownload} from "../lib/security";
import {Button,Card,Badge,Stat,Input,Select,Textarea,Modal,ProfileModal} from "../components/UI";
import MapPanel from "../components/MapPanel";
import PWAInstall from "../components/PWAInstall";
import {getBestPosition} from "../lib/gps";

const tabs=["Overview","Attendance","History","Users","Departments","Leave","Reports","Settings","Developers"];

const TZ="Africa/Dar_es_Salaam";
const localDate=()=>new Intl.DateTimeFormat("en-CA",{timeZone:TZ,year:"numeric",month:"2-digit",day:"2-digit"}).format(new Date());


export default function AdminDashboard({user,onLogout}){
 const isDeptAdmin=user?.category==="DEPARTMENT_ADMIN",[tab,setTab]=useState("Overview"),[filter,setFilter]=useState("ALL"),[users,setUsers]=useState([]),[attendance,setAttendance]=useState([]),[leaves,setLeaves]=useState([]),[departments,setDepartments]=useState([]),[settings,setSettings]=useState(null),[alerts,setAlerts]=useState([]),[msg,setMsg]=useState(""),[showUser,setShowUser]=useState(false),[showDepartment,setShowDepartment]=useState(false),[showDeptAdmin,setShowDeptAdmin]=useState(false),[showProfile,setShowProfile]=useState(false),[reportOpen,setReportOpen]=useState(false),[reportKind,setReportKind]=useState("ALL"),[reportMode,setReportMode]=useState("TODAY"),[reportDate,setReportDate]=useState(localDate()),[reportDepartment,setReportDepartment]=useState(isDeptAdmin?user.department_id:"ALL"),[notifications,setNotifications]=useState([]),[departmentName,setDepartmentName]=useState(""),[deptAdminForm,setDeptAdminForm]=useState({full_name:"",official_email:"",department_id:""}),[form,setForm]=useState({full_name:"",department_id:isDeptAdmin?user.department_id:"",official_email:""}),[busy,setBusy]=useState(false),[editMember,setEditMember]=useState(null),[modalError,setModalError]=useState(""),[printHtml,setPrintHtml]=useState("");

 async function loadNotifications(){try{const{data,error}=await supabase.from("notifications").select("*").eq("user_id",user.id).order("created_at",{ascending:false}).limit(30);if(error)throw error;setNotifications(data||[])}catch(e){}}
 async function markNotificationRead(id){const{error}=await supabase.from("notifications").update({is_read:true}).eq("id",id).eq("user_id",user.id);if(!error)setNotifications(prev=>prev.map(x=>x.id===id?{...x,is_read:true}:x))}
 async function markAllNotificationsRead(){const{error}=await supabase.from("notifications").update({is_read:true}).eq("user_id",user.id).eq("is_read",false);if(!error)setNotifications(prev=>prev.map(x=>({...x,is_read:true})))}
 async function load(){
  setMsg("");
  try{
   const base=await Promise.all([
    supabase.from("profiles").select("*").order("created_at",{ascending:false}),
    supabase.from("attendance_records").select("*,profiles(full_name,user_code,category,department,department_id)").order("captured_at",{ascending:false}).limit(5000),
    supabase.from("app_settings").select("*").single(),
    supabase.from("departments").select("*").order("name")
   ]);
   const [{data:u,error:ue},{data:a,error:ae},{data:s,error:se},{data:d,error:de}]=base;
   let l={items:[]};
   l=await invoke("admin-request-queue",{type:"LEAVE"});
   if(ue)throw ue;
   if(ae)throw ae;
   if(se)throw se;
   if(de)throw de;
   setUsers((u||[]).filter(x=>x.id===user.id||x.category!=="HR_ADMIN"));setAttendance(a||[]);setDepartments(d||[]);setLeaves(l?.items||[]);setSettings(s);
   const today=localDate();
   const overdue=(l?.items||[]).filter(x=>x.status==="APPROVED"&&x.end_date<today).map(x=>({userId:x.user_id,fullName:x.profiles?.full_name,endDate:x.end_date}));
   setAlerts(overdue);
  }catch(e){
   setLeaves([]);setMsg(e?.message||"Unable to load HR data.");
  }
 }
 useEffect(()=>{load();loadNotifications();const timer=setInterval(loadNotifications,15000);return()=>clearInterval(timer)},[]);
 const students=users.filter(x=>x.category==="FIELD_STUDENT");
 const visibleTabs=isDeptAdmin?["Overview","Attendance","History","Users","Leave","Reports","Developers"]:tabs;
 const filteredAttendance=attendance.filter(r=>filter==="ALL"||r.profiles?.category==="FIELD_STUDENT");
 const today=localDate(), todayRows=filteredAttendance.filter(r=>r.attendance_date===today);
 const present=new Set(todayRows.filter(r=>r.action==="CHECK_IN").map(r=>r.user_id));
 const late=todayRows.filter(r=>r.status==="LATE"&&r.action==="CHECK_IN").length;
 const chart=useMemo(()=>{const out=[];const now=new Date();for(let i=6;i>=0;i--){const d=new Date(now);d.setDate(d.getDate()-i);const iso=new Intl.DateTimeFormat("en-CA",{timeZone:TZ,year:"numeric",month:"2-digit",day:"2-digit"}).format(d);const rows=attendance.filter(r=>r.attendance_date===iso&&r.action==="CHECK_IN");out.push({day:iso.slice(5),students:rows.filter(r=>r.profiles?.category==="FIELD_STUDENT").length})}return out},[attendance]);

 async function addUser(e){e.preventDefault();setBusy(true);setMsg("");try{const email=form.official_email.trim().toLowerCase();const departmentId=form.department_id||null;const r=await invoke("admin-users",{action:"create",user:{full_name:form.full_name,department_id:departmentId,official_email:email}});setMsg(`Created ${r.user.full_name} (${r.user.user_code}) in ${r.user.department||departments.find(x=>x.id===departmentId)?.name||"Department"}. Default password: ${r.user.default_password}`);setShowUser(false);setForm({full_name:"",department_id:isDeptAdmin?user.department_id:"",official_email:""});await load()}catch(e){setMsg(e.message||"Unable to create account.")}finally{setBusy(false)}}
 async function importFile(e){const file=e.target.files?.[0];if(!file)return;setBusy(true);setMsg("");try{const buf=await file.arrayBuffer();const wb=XLSX.read(buf);const rows=XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]],{defval:""});const normalized=rows.map(r=>{const rawDept=String(r.Department_ID||r.department_id||r.Department||r.department||"").trim();const dept=departments.find(d=>d.id===rawDept||d.name.toLowerCase()===rawDept.toLowerCase());return {full_name:r["Full Name"]||r.full_name,department_id:dept?.id||"",official_email:r.Email||r.official_email||""}});const r=await invoke("admin-users",{action:"bulk_create",users:normalized});setMsg(`Imported ${r.created} users; ${r.skipped} skipped.`);load()}catch(e){setMsg(e.message)}finally{setBusy(false);e.target.value=""}}
 async function updateMember(values){
  if(!values.full_name.trim()||!values.official_email.trim()||!values.department_id){setModalError("Full name, official email and department are required.");return}
  setBusy(true);setModalError("");
  try{
   await invoke("admin-users",{action:"update",user_id:values.id,full_name:values.full_name.trim(),official_email:values.official_email.trim(),department_id:values.department_id,phone:values.phone.trim()});
   const selectedDepartment=departments.find(x=>x.id===values.department_id);
   const{error:ue}=await supabase.from("profiles").update({full_name:values.full_name.trim(),official_email:values.official_email.trim().toLowerCase(),department_id:values.department_id,department:selectedDepartment?.name||null,phone:values.phone.trim(),updated_at:new Date().toISOString()}).eq("id",values.id);
   if(ue)throw ue;
   setMsg("Member information updated successfully.");setEditMember(null);await load();
  }catch(e){setModalError(e.message||"Unable to update member.")}finally{setBusy(false)}
 }
 async function deleteMember(member){
  if(!window.confirm(`Deactivate ${member.full_name} (${member.user_code})? Attendance and leave history will be preserved.`))return;
  try{
    await invoke("admin-users",{action:"delete",user_id:member.id});
    setMsg("Member account deactivated successfully."); await load();
  }catch(e){setMsg(e.message||"Unable to deactivate member.")}
 }
 async function updateRadius(radius){try{const{error}=await supabase.from("app_settings").update({geofence_radius_m:radius}).eq("id",true);if(error)throw error;setSettings({...settings,geofence_radius_m:radius});setMsg(`Geofence radius set to ${radius}m.`)}catch(e){setMsg(e.message)}}
 function exportRows(kind,departmentId=reportDepartment){const rows=attendance.filter(r=>kind==="ALL"|| (r.profiles?.category==="FIELD_STUDENT")).filter(r=>departmentId==="ALL"||!departmentId||r.profiles?.department_id===departmentId).map(r=>({Date:r.attendance_date,Name:r.profiles?.full_name,ID:r.profiles?.user_code,Category:r.profiles?.category,Department:r.profiles?.department,Action:r.action,Time:new Date(r.captured_at).toLocaleString(),Distance_M:r.distance_m,Accuracy_M:r.accuracy_m,Status:r.status}));csvDownload(`TCC_${kind}_${departmentId==="ALL"?"ALL":(departments.find(d=>d.id===departmentId)?.name||"DEPARTMENT")}_Attendance.csv`,rows)}
 const todayReport=users.filter(u=>u.category==="FIELD_STUDENT").map(u=>{
  const rows=attendance.filter(r=>r.user_id===u.id&&r.attendance_date===today);
  const ci=rows.filter(r=>r.action==="CHECK_IN").sort((a,b)=>new Date(a.captured_at)-new Date(b.captured_at))[0];
  const co=rows.filter(r=>r.action==="CHECK_OUT").sort((a,b)=>new Date(b.captured_at)-new Date(a.captured_at))[0];
  const onLeave=leaves.some(l=>l.user_id===u.id&&l.status==="APPROVED"&&l.start_date<=today&&l.end_date>=today);
  return {u,ci,co,onLeave};
 });
 const printReport=async(kind,mode="TODAY",date=today,departmentId=reportDepartment)=>{
  let scope=mode;
  let selectedDate=date||today;
  if(!["ALL","TODAY","DATE"].includes(scope)){setMsg("Invalid report selection.");return}
  if(scope==="DATE"&&!/^\d{4}-\d{2}-\d{2}$/.test(selectedDate)){setMsg("Please select a valid report date.");return}
  setReportOpen(false);
  const esc=v=>String(v??"-").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]));
  const tm=v=>v?new Date(v).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}):"-";
  let title="TCC ATTENDANCE REPORT", subtitle="";
  let bodyRows="";
  if(scope==="ALL"){
   const records=attendance.filter(r=>kind==="ALL"|| (r.profiles?.category==="FIELD_STUDENT")).filter(r=>departmentId==="ALL"||!departmentId||r.profiles?.department_id===departmentId);
   bodyRows=records.map((r,i)=>`<tr><td>${i+1}</td><td>${esc(r.attendance_date)}</td><td>${esc(r.profiles?.full_name)}</td><td>${esc(r.profiles?.user_code)}</td><td>Field Student</td><td>${esc(r.profiles?.department||"-")}</td><td>${esc(r.action)}</td><td>${tm(r.captured_at)}</td><td>${Math.round(r.distance_m||0)}m</td><td>${esc(r.status)}</td></tr>`).join("");
   subtitle="All attendance records";
  }else{
   const rows=users.filter(u=>u.category==="FIELD_STUDENT").filter(u=>kind==="ALL"||u.category===kind).filter(u=>departmentId==="ALL"||!departmentId||u.department_id===departmentId).map((u,i)=>{
    const rs=attendance.filter(r=>r.user_id===u.id&&r.attendance_date===selectedDate);
    const ci=rs.filter(r=>r.action==="CHECK_IN").sort((a,b)=>new Date(a.captured_at)-new Date(b.captured_at))[0];
    const co=rs.filter(r=>r.action==="CHECK_OUT").sort((a,b)=>new Date(b.captured_at)-new Date(a.captured_at))[0];
    const leave=leaves.some(l=>l.user_id===u.id&&l.status==="APPROVED"&&l.start_date<=selectedDate&&l.end_date>=selectedDate);
    const status=leave?"On Leave":ci?(ci.status==="LATE"?"Late":"Present"):"Absent";
    return `<tr><td>${i+1}</td><td>${esc(u.full_name)}</td><td>${esc(u.user_code)}</td><td>Field Student</td><td>${esc(u.department||departments.find(d=>d.id===u.department_id)?.name||"-")}</td><td>${tm(ci?.captured_at)}</td><td>${tm(co?.captured_at)}</td><td>${status}</td><td>${ci?`${Math.round(ci.distance_m||0)}m`:"-"}</td></tr>`;
   }).join("");
   title="TCC ATTENDANCE REPORT";subtitle=`Date: ${selectedDate}`;bodyRows=rows;
  }
  const headers=scope==="ALL"?"<th>#</th><th>Date</th><th>Name</th><th>ID</th><th>Category</th><th>Department</th><th>Action</th><th>Time</th><th>Distance</th><th>Status</th>":"<th>#</th><th>Name</th><th>ID</th><th>Category</th><th>Department</th><th>Sign In</th><th>Sign Out</th><th>Status</th><th>Location</th>";
  let logo="";
  try{const r=await fetch("/icons/tcc-logo.png",{cache:"no-store"});if(r.ok){const b=await r.blob();logo=await new Promise(resolve=>{const fr=new FileReader();fr.onload=()=>resolve(fr.result);fr.readAsDataURL(b)})}}catch{}
  const html=`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TCC Attendance Report</title><style>
  @page{size:A4 landscape;margin:7mm}
  *{box-sizing:border-box}
  body{font-family:Arial,Helvetica,sans-serif;color:#0f172a;margin:0;background:#fff}
  .toolbar{display:flex;justify-content:flex-end;gap:8px;padding:10px 0;position:sticky;top:0;background:#fff;z-index:5}
  .toolbar button{border:0;border-radius:10px;padding:9px 13px;font-weight:700;cursor:pointer}
  .print{background:#0b1f3a;color:#fff}.pdf{background:#059669;color:#fff}
  .report-head{text-align:center;padding:0 4px 7px;border-bottom:3px solid #1769aa;margin-bottom:8px}
  .report-head img{display:block;width:76px;height:76px;object-fit:contain;margin:0 auto 4px;background:transparent;border:0;padding:0}
  .report-head .office{margin:0;font-size:15px;line-height:1.15;font-weight:900;letter-spacing:.15px;color:#0b1f3a;text-transform:uppercase}
  .report-head .council{margin:3px 0 0;font-size:18px;line-height:1.15;font-weight:900;color:#1769aa;text-transform:uppercase}
  .report-head .title{margin:2px 0 0;font-size:17px;line-height:1.15;font-weight:900;color:#0b1f3a;text-transform:uppercase}
  .report-head .date{margin:3px 0 0;font-size:12px;font-weight:800;color:#0b1f3a}
  table{width:100%;table-layout:fixed;border-collapse:collapse;font-size:${scope==="ALL"?"8.2":"9.1"}px;line-height:1.15}
  thead{display:table-header-group}
  tr{break-inside:avoid;page-break-inside:avoid}
  th,td{border:1px solid #9bb6d0;padding:4px 4px;text-align:left;vertical-align:middle;overflow-wrap:anywhere;word-break:break-word}
  th{background:#07549a;color:#fff;text-align:center;font-weight:900}
  tbody tr:nth-child(even){background:#eef5fb}
  th:nth-child(1),td:nth-child(1){width:3%}
  th:nth-child(2),td:nth-child(2){width:${scope==="ALL"?"9%":"14%"}}
  th:nth-child(3),td:nth-child(3){width:${scope==="ALL"?"14%":"14%"}}
  th:nth-child(4),td:nth-child(4){width:10%}
  th:nth-child(5),td:nth-child(5){width:12%}
  th:nth-child(6),td:nth-child(6){width:${scope==="ALL"?"9%":"9%"}}
  th:nth-child(7),td:nth-child(7){width:${scope==="ALL"?"9%":"9%"}}
  th:nth-child(8),td:nth-child(8){width:10%}
  th:nth-child(9),td:nth-child(9){width:${scope==="ALL"?"8%":"11%"}}
  th:nth-child(10),td:nth-child(10){width:14%}
  .foot{display:flex;justify-content:space-between;align-items:center;border-top:3px solid #1769aa;margin-top:9px;padding-top:5px;font-size:8px}
  .foot .motto{font-style:italic;color:#1769aa;font-weight:700}
  @media print{.toolbar{display:none!important}body{print-color-adjust:exact;-webkit-print-color-adjust:exact}.report-head{break-inside:avoid;page-break-inside:avoid}.foot{break-inside:avoid;page-break-inside:avoid}}
  </style></head><body>
  <div class="toolbar"><button class="print" onclick="window.print()">Print Report</button><button class="pdf" onclick="window.print()">Save as PDF</button></div>
  <section class="report-head">${logo?`<img src="${logo}" alt="Tanga City Council">`:""}<p class="office">PRIME MINISTER OFFICE REGIONAL ADMINISTRATION AND LOCAL GOVERNMENT</p><p class="council">TANGA CITY COUNCIL</p><p class="title">TCC ATTENDANCE REPORT</p><p class="date">${esc(subtitle||`Date: ${selectedDate}`)}</p></section>
  <table><thead><tr>${headers}</tr></thead><tbody>${bodyRows||`<tr><td colspan="${scope==="ALL"?10:9}" style="text-align:center">No attendance records found.</td></tr>`}</tbody></table>
  <div class="foot"><span>Prepared by: TCC Attendance System</span><span class="motto">For a Better Tomorrow</span><span>Page 1 of 1</span></div>
  </body></html>`;
  setPrintHtml(html);
 };

 return <div className="min-h-screen bg-slate-100"><header className="admin-header sticky top-0 z-50 bg-[#0b1f3a] text-white shadow"><div className="admin-header-inner mx-auto flex max-w-[1500px] items-center justify-between gap-4 px-4 py-3 sm:px-6 sm:py-4"><div className="admin-brand flex min-w-0 items-center gap-3"><img src="/icons/tcc-logo.png" alt="TCC" className="h-11 w-11 shrink-0 rounded-xl object-contain bg-white p-0.5 shadow-sm sm:h-12 sm:w-12"/><div className="min-w-0"><b className="block truncate text-lg font-extrabold tracking-tight sm:text-xl">TCC Attendance</b><div className="truncate text-xs text-slate-300 sm:text-sm">{isDeptAdmin?`Department Admin · ${user.department||"Department"}`:"Primary HR Admin"}</div></div></div><div className="admin-actions flex shrink-0 items-center justify-end gap-2 sm:gap-2.5"><PWAInstall/><Button variant="ghost" onClick={()=>setShowProfile(true)} className="header-action"><UserRound size={17}/> <span>Profile</span></Button><button onClick={()=>{setTab("Overview");setTimeout(()=>document.getElementById("admin-notifications")?.scrollIntoView({behavior:"smooth",block:"center"}),50)}} className="relative grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-white/10 text-white transition hover:bg-white/20" aria-label="Notifications"><Bell size={19}/>{notifications.some(x=>!x.is_read)&&<span className="absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-red-500 px-1 text-[10px] font-black">{notifications.filter(x=>!x.is_read).length>9?"9+":notifications.filter(x=>!x.is_read).length}</span>}</button><Badge tone="green"><span className="hidden sm:inline">{isDeptAdmin?"DEPARTMENT ADMIN":"HR ADMIN"}</span><span className="sm:hidden">{isDeptAdmin?"DEPT ADMIN":"HR ADMIN"}</span></Badge><Button variant="ghost" onClick={onLogout} className="header-action"><LogOut size={17}/> <span>Logout</span></Button></div></div></header>
 <div className="mx-auto max-w-[1500px] p-3 sm:p-6"><div className="admin-nav mb-5 flex gap-2 overflow-x-auto px-1 pb-1 print:hidden">{visibleTabs.map(x=><button key={x} onClick={()=>setTab(x)} className={`whitespace-nowrap rounded-lg px-3 py-2 text-xs font-bold sm:rounded-xl sm:px-4 sm:text-sm ${tab===x?"bg-[#0b1f3a] text-white":"bg-white text-slate-600"}`}>{x}</button>)}</div>{msg&&<div className="fixed right-4 top-24 z-[900] max-w-sm rounded-2xl border border-blue-100 bg-white px-4 py-3 text-sm font-semibold text-blue-800 shadow-2xl">{msg}</div>}
 {tab==="Overview"&&<Overview students={students} present={present} late={late} chart={chart} alerts={alerts} setTab={setTab} notifications={notifications} markNotificationRead={markNotificationRead} markAllNotificationsRead={markAllNotificationsRead}/>}
 {tab==="Attendance"&&<Attendance rows={todayRows} filter={filter} setFilter={setFilter} today={today}/>}
 {tab==="History"&&<History rows={filteredAttendance} filter={filter} setFilter={setFilter} today={today}/>}
 {tab==="Users"&&<UsersTab users={users} filter={filter} setFilter={setFilter} onAdd={()=>setShowUser(true)} onImport={importFile} onEdit={member=>{setModalError("");setEditMember(member)}} onDelete={deleteMember} departmentAdmin={isDeptAdmin}/>}
 {tab==="Departments"&&!isDeptAdmin&&<DepartmentsTab departments={departments} users={users} onAdd={()=>setShowDepartment(true)} onAdmin={()=>setShowDeptAdmin(true)} onRefresh={load}/>}
 {tab==="Leave"&&<LeaveTab rows={leaves} reload={load} isDeptAdmin={isDeptAdmin}/>}
 {tab==="Reports"&&<Reports exportRows={exportRows} onPrint={(k)=>{setReportKind(k);setReportOpen(true)}} departments={departments} departmentId={reportDepartment} setDepartmentId={setReportDepartment} fixedDepartment={isDeptAdmin}/>}
 {tab==="Settings"&&<Settings settings={settings} updateRadius={updateRadius} setMsg={setMsg}/>}
 {tab==="Developers"&&<Developers/>}
 </div>
 {reportOpen&&<ReportSelector open={reportOpen} onClose={()=>setReportOpen(false)} mode={reportMode} setMode={setReportMode} date={reportDate} setDate={setReportDate} departments={departments} departmentId={reportDepartment} setDepartmentId={setReportDepartment} fixedDepartment={isDeptAdmin} onGenerate={()=>printReport(reportKind,reportMode,reportDate,reportDepartment)}/>}
 {printHtml&&<PrintReportPreview html={printHtml} onClose={()=>setPrintHtml("")}/>}
 {showProfile&&<ProfileModal user={user} onClose={()=>setShowProfile(false)}/>}
 {showUser&&<Modal title="Add Field Student" onClose={()=>setShowUser(false)}><form onSubmit={addUser} className="space-y-4"><Input label="Full Name" required value={form.full_name} onChange={e=>setForm({...form,full_name:e.target.value})}/><Select label="Department" required value={form.department_id} onChange={e=>setForm({...form,department_id:e.target.value})} disabled={isDeptAdmin}><option value="">Select department</option>{departments.filter(d=>d.is_active).map(d=><option key={d.id} value={d.id}>{d.name}</option>)}</Select><Input label="Official Email" type="email" required value={form.official_email} onChange={e=>setForm({...form,official_email:e.target.value})}/><Button disabled={busy} variant="success" className="w-full">{busy?"Creating…":"Create Account"}</Button></form></Modal>}
 {showDepartment&&<Modal title="Register Department" onClose={()=>{setShowDepartment(false);setModalError("")}}><form onSubmit={async e=>{e.preventDefault();const name=departmentName.trim();if(!name){setModalError("Department name is required.");return}setBusy(true);setModalError("");try{const{data,error}=await supabase.from("departments").insert({name}).select().single();if(error)throw error;setMsg(`Department ${data.name} registered successfully.`);setDepartmentName("");setShowDepartment(false);await load()}catch(e){setModalError(e.code==="23505"?"That department already exists.":e.message||"Unable to register department.")}finally{setBusy(false)}}} className="space-y-4"><Input label="Department Name" required value={departmentName} onChange={e=>{setDepartmentName(e.target.value);setModalError("")}}/>{modalError&&<div className="rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700">{modalError}</div>}<Button disabled={busy} variant="success" className="w-full">{busy?"Registering…":"Register Department"}</Button></form></Modal>}
 {editMember&&<EditMemberModal member={editMember} departments={departments} busy={busy} error={modalError} onClose={()=>{setEditMember(null);setModalError("")}} onSave={updateMember}/>}
 {showDeptAdmin&&<Modal title="Register Department Admin" onClose={()=>{setShowDeptAdmin(false);setModalError("")}}><form onSubmit={async e=>{e.preventDefault();if(!deptAdminForm.full_name.trim()||!deptAdminForm.official_email.trim()||!deptAdminForm.department_id){setModalError("Full name, official email and department are required. Admin ID is generated automatically.");return}setBusy(true);setModalError("");try{const r=await invoke("admin-users",{action:"create_department_admin",user:deptAdminForm});setMsg(`Department Admin created: ${r.user.user_code} for ${r.user.department}. Default password: ${r.user.default_password}`);setDeptAdminForm({full_name:"",official_email:"",department_id:""});setShowDeptAdmin(false);await load()}catch(e){setModalError(e.message||"Unable to create Department Admin.")}finally{setBusy(false)}}} className="space-y-4"><Input label="Full Name" required value={deptAdminForm.full_name} onChange={e=>{setDeptAdminForm({...deptAdminForm,full_name:e.target.value});setModalError("")}}/><Input label="Official Email" type="email" required value={deptAdminForm.official_email} onChange={e=>{setDeptAdminForm({...deptAdminForm,official_email:e.target.value});setModalError("")}}/><Select label="Department" required value={deptAdminForm.department_id} onChange={e=>{setDeptAdminForm({...deptAdminForm,department_id:e.target.value});setModalError("")}}><option value="">Select department</option>{departments.filter(d=>d.is_active).map(d=><option key={d.id} value={d.id}>{d.name}</option>)}</Select>{modalError&&<div className="rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700">{modalError}</div>}<Button disabled={busy} variant="success" className="w-full">{busy?"Creating…":"Create Department Admin"}</Button></form></Modal>}
 </div>
}

function PrintReportPreview({html,onClose}){
 const frameRef=useRef(null);
 const print=()=>{
  try{frameRef.current?.contentWindow?.focus();frameRef.current?.contentWindow?.print();}
  catch{window.print();}
 };
 return <div className="fixed inset-0 z-[2000] bg-slate-950/80 p-2 sm:p-5">
  <div className="mx-auto flex h-full max-w-6xl flex-col overflow-hidden rounded-2xl bg-white shadow-2xl">
   <div className="flex shrink-0 items-center justify-between gap-2 border-b bg-white px-3 py-2 sm:px-4">
    <div><b className="text-sm text-slate-900 sm:text-base">Attendance Report</b><div className="text-[11px] text-slate-500">Preview before printing</div></div>
    <div className="flex gap-2">
     <button type="button" onClick={onClose} className="rounded-xl border border-slate-200 px-3 py-2 text-xs font-bold text-slate-700">Close</button>
     <button type="button" onClick={print} className="rounded-xl bg-[#0b1f3a] px-4 py-2 text-xs font-black text-white">Print Report</button>
    </div>
   </div>
   <iframe ref={frameRef} title="Attendance Report Preview" srcDoc={html} className="min-h-0 w-full flex-1 border-0 bg-white"/>
  </div>
 </div>}

function Developers(){
 const team=[
  {name:"ALLY ALLY",school:"Mbeya University (MUST)",course:"ICT",role:"Main Developer",tone:"Lead System Architect & Main Developer",text:"The driving force behind the TCC Attendance Portal, transforming the attendance challenge into a complete digital solution through architecture, coding, integration and problem-solving. This contribution brought the vision from an idea to a working system built with purpose, discipline and technical creativity."},
  {name:"NICOLOUS YOHANA",school:"Kampala",course:"IT",role:"Testing",tone:"Quality Assurance Contributor",text:"A committed testing contributor whose careful examination helped reveal weaknesses, verify expected behavior and strengthen confidence in the final system. His contribution represents the discipline of asking whether software truly works, not merely whether it looks complete."},
  {name:"YAZIDU YUSUFU",school:"Mzumbe",course:"ICTM",role:"Testing",tone:"Testing & Quality Contributor",text:"A valuable quality contributor who participated in testing and verification. His work helped challenge the system under practical conditions and contributed to making the final product more dependable for real users."},
  {name:"SALMA BURHANI",school:"KITM",course:"IT",role:"Deployment and Tools",tone:"Deployment & Tools Contributor",text:"A dedicated contributor in deployment and development tools, helping bridge the gap between a project on a developer's computer and a system ready to be accessed and tested by real users."},
  {name:"NICHOLAS MARTIN",school:"CBE",course:"IT",role:"Deployment and Tools",tone:"Deployment & Tools Contributor",text:"A committed deployment contributor whose work supported the practical delivery of the system. His contribution reflects the importance of reliable tools, environments and the final journey from development to production."},
  {name:"ADIIL JUMA",school:"Masai Utalii",course:"ICT",role:"Database",tone:"Database Contributor",text:"A key database contributor who helped shape the foundation where the system's information lives. His contribution highlights the importance of organized data, relationships, accuracy and reliable storage in a professional information system."},
  {name:"FADHILA SALUM",school:"Mzumbe",course:"ICTM",role:"Database",tone:"Database & Data Contributor",text:"A dedicated contributor to the database side of the project, helping strengthen the data foundation behind attendance and management operations. Her contribution is part of what turns application screens into a system with meaningful, persistent information."},
  {name:"HERIETH MHINA",school:"Mzumbe",course:"IT",role:"Deployment and Tools",tone:"Deployment & Tools Contributor",text:"A valuable deployment and tools contributor who supported the practical engineering environment around the project. Her contribution helped the team work toward a system that can move beyond development and reach its intended users."},
  {name:"OMARY JUMA",school:"KITM",course:"IT",role:"Code",tone:"Code & Development Contributor",text:"A committed code contributor whose involvement strengthened the implementation side of the project. His contribution reflects the teamwork required to turn technical ideas into working features and maintainable software."}
 ];
 return <div className="space-y-6">
  <div className="rounded-3xl bg-[#0b1f3a] p-6 text-white shadow-lg sm:p-8">
   <div className="flex flex-col gap-5 sm:flex-row sm:items-center">
    <img src="/icons/tcc-logo.png" alt="Tanga City Council" className="h-20 w-20 rounded-2xl bg-white object-contain p-1 shadow"/>
    <div><div className="text-xs font-black uppercase tracking-[0.22em] text-emerald-300">A Record of Contribution</div><h1 className="mt-2 text-3xl font-black sm:text-4xl">System Developers & Contributors</h1><p className="mt-2 max-w-3xl text-sm leading-6 text-slate-300">This section permanently records the people whose knowledge, effort, testing, data work, deployment skills and technical contribution helped bring the TCC Attendance Portal to life.</p></div>
   </div>
  </div>
  <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
   {team.map((m,i)=><Card key={m.name} className="overflow-hidden">
    <div className="h-2 bg-gradient-to-r from-[#0b1f3a] via-emerald-500 to-amber-400"/>
    <div className="p-5">
     <div className="flex items-start gap-4"><div className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-[#0b1f3a] text-lg font-black text-white">{m.name.split(/\s+/).slice(0,2).map(x=>x[0]).join("")}</div><div className="min-w-0"><h2 className="font-black text-slate-900">{m.name}</h2><div className="mt-1 text-xs font-bold text-emerald-700">{m.tone}</div></div></div>
     <div className="mt-4 grid grid-cols-2 gap-2 text-xs"><div className="rounded-xl bg-slate-50 p-3"><div className="font-bold uppercase text-slate-400">Institution</div><div className="mt-1 font-semibold text-slate-700">{m.school}</div></div><div className="rounded-xl bg-slate-50 p-3"><div className="font-bold uppercase text-slate-400">Course</div><div className="mt-1 font-semibold text-slate-700">{m.course}</div></div></div>
     <div className="mt-4"><Badge tone="blue">{m.role}</Badge></div>
     <p className="mt-4 text-sm leading-6 text-slate-600">{m.text}</p>
    </div>
   </Card>)}
  </div>
  <Card className="p-6 text-center sm:p-8"><div className="mx-auto max-w-4xl"><h2 className="text-2xl font-black text-[#0b1f3a]">A Legacy Written in Teamwork</h2><p className="mt-4 text-sm leading-7 text-slate-600">The TCC Attendance Portal is more than software. It is a record of collaboration, learning, persistence and shared responsibility. Every contribution recorded here forms part of the history of the system and deserves recognition. May the names on this page remain connected to the knowledge, creativity and teamwork that made this project possible.</p><p className="mt-4 font-bold text-emerald-700">Built with knowledge. Strengthened by teamwork. Preserved as a legacy.</p></div></Card>
 </div>
}

function Overview({students,present,late,chart,alerts,setTab,notifications,markNotificationRead,markAllNotificationsRead}){return <div className="space-y-5"><div><h1 className="text-2xl font-black">HR Dashboard</h1><p className="text-sm text-slate-500">Live field student attendance overview.</p></div><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3"><Stat label="Field Students" value={students.length} icon={<Users/>} tone="green"/><Stat label="Signed In Today" value={present.size} icon={<CheckCircle2/>} tone="green"/><Stat label="Late Arrivals" value={late} icon={<Clock3/>} tone="amber"/></div><Card id="admin-notifications" className="overflow-hidden"><div className="flex items-center justify-between gap-3 border-b p-4"><div className="flex items-center gap-3"><div className="rounded-xl bg-blue-50 p-2 text-blue-700"><Bell size={20}/></div><div><h2 className="font-black">Admin Notifications</h2><p className="text-xs text-slate-500">{notifications.filter(x=>!x.is_read).length?`${notifications.filter(x=>!x.is_read).length} unread request notification${notifications.filter(x=>!x.is_read).length===1?"":"s"}`:"No unread notifications"}</p></div></div>{notifications.some(x=>!x.is_read)&&<Button variant="outline" onClick={markAllNotificationsRead}><CheckCheck size={16}/> Mark all read</Button>}</div><div className="divide-y">{notifications.length===0?<div className="p-5 text-sm text-slate-500">No notifications yet.</div>:notifications.slice(0,8).map(n=><div key={n.id} className={`flex gap-3 p-4 ${n.is_read?"bg-white":"bg-blue-50/60"}`}><div className={`mt-1 h-2.5 w-2.5 shrink-0 rounded-full ${n.type==="SUCCESS"?"bg-emerald-500":n.type==="WARNING"?"bg-amber-500":n.type==="ERROR"?"bg-red-500":"bg-blue-500"}`}/><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center justify-between gap-2"><b className="text-sm">{n.title}</b><span className="text-[11px] text-slate-400">{new Date(n.created_at).toLocaleString()}</span></div><p className="mt-1 text-sm text-slate-600">{n.message}</p>{!n.is_read&&<button onClick={()=>markNotificationRead(n.id)} className="mt-2 text-xs font-bold text-blue-700">Mark as read</button>}</div></div>)}</div></Card><div className="grid gap-5 lg:grid-cols-[1.3fr_.7fr]"><Card className="p-5"><h2 className="font-black">7-Day Field Student Attendance Trend</h2><div className="mt-4 h-72"><ResponsiveContainer><BarChart data={chart}><CartesianGrid strokeDasharray="3 3"/><XAxis dataKey="day"/><YAxis/><Tooltip/><Bar dataKey="students" name="Field Students" fill="#0b1f3a" radius={[6,6,0,0]}/></BarChart></ResponsiveContainer></div></Card><MapPanel/></div>{alerts.length>0&&<Card className="border-amber-200 bg-amber-50 p-5"><h2 className="font-black text-amber-900">Overdue Leave Alerts</h2><div className="mt-3 space-y-2">{alerts.map((a,i)=><div key={i} className="rounded-xl bg-white p-3 text-sm text-amber-900">Alert: <b>{a.fullName}</b> has exceeded approved leave duration (Ended on {a.endDate}) and has not signed in today.</div>)}</div><Button variant="warning" className="mt-4" onClick={()=>setTab("Leave")}>Review Leave</Button></Card>}</div>}
function Attendance({rows,filter,setFilter,today}){return <div className="space-y-5"><div className="flex flex-wrap items-end justify-between gap-3"><div><h1 className="text-2xl font-black">Today's Attendance</h1><p className="text-sm text-slate-500">Only attendance for {today} is shown here.</p></div><Select label="Category" value={filter} onChange={e=>setFilter(e.target.value)}><option value="ALL">All</option><option value="FIELD_STUDENT">Field Students</option></Select></div><Card className="overflow-hidden"><Table rows={rows}/></Card></div>}
function History({rows,filter,setFilter,today}){const [date,setDate]=useState("");const historyRows=rows.filter(r=>date?(r.attendance_date===date&&r.attendance_date<today):r.attendance_date<today);return <div className="space-y-5"><div className="flex flex-wrap items-end justify-between gap-3"><div><h1 className="text-2xl font-black">Attendance History</h1><p className="text-sm text-slate-500">Previous days are kept here. Today remains in Daily Attendance.</p></div><div className="flex flex-wrap gap-2"><Input label="Choose date" type="date" value={date} max={today} onChange={e=>setDate(e.target.value)}/><Select label="Category" value={filter} onChange={e=>setFilter(e.target.value)}><option value="ALL">All</option><option value="FIELD_STUDENT">Field Students</option></Select></div></div><Card className="overflow-hidden"><Table rows={historyRows}/></Card></div>}
function Table({rows}){return <div className="overflow-x-auto"><table className="w-full text-left text-sm"><thead className="bg-slate-50 text-xs uppercase text-slate-500"><tr><th className="px-5 py-3">Name</th><th className="px-5 py-3">ID</th><th className="px-5 py-3">Category</th><th className="px-5 py-3">Date</th><th className="px-5 py-3">Action</th><th className="px-5 py-3">Time</th><th className="px-5 py-3">Distance</th><th className="px-5 py-3">Status</th></tr></thead><tbody className="divide-y">{rows.map(r=><tr key={r.id}><td className="px-5 py-3 font-semibold">{r.profiles?.full_name}</td><td className="px-5 py-3">{r.profiles?.user_code}</td><td className="px-5 py-3"><Badge tone={r.profiles?.category==="FIELD_STUDENT"?"blue":"green"}>Field Student</Badge></td><td className="px-5 py-3">{r.attendance_date}</td><td className="px-5 py-3">{r.action==="CHECK_IN"?"Sign In":"Sign Out"}</td><td className="px-5 py-3">{new Date(r.captured_at).toLocaleTimeString()}</td><td className="px-5 py-3">{Math.round(r.distance_m)}m</td><td className="px-5 py-3"><Badge tone={r.status==="LATE"?"amber":"green"}>{r.status}</Badge></td></tr>)}</tbody></table></div>}
function EditMemberModal({member,departments,busy,error,onClose,onSave}){
 const [form,setForm]=useState({id:member.id,full_name:member.full_name||"",official_email:member.official_email||"",phone:member.phone||"",department_id:member.department_id||""});
 return <Modal title="Edit Member Information" onClose={onClose}><form onSubmit={e=>{e.preventDefault();onSave(form)}} className="space-y-4"><div className="rounded-2xl bg-slate-50 p-4"><div className="text-xs font-black uppercase tracking-wide text-slate-400">Account</div><div className="mt-1 font-black text-slate-900">{member.user_code}</div><div className="mt-1 text-sm text-slate-500">Field Student</div></div><Input label="Full Name" required value={form.full_name} onChange={e=>setForm({...form,full_name:e.target.value})}/><Input label="Official Email" type="email" required value={form.official_email} onChange={e=>setForm({...form,official_email:e.target.value})}/><Input label="Phone Number" value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})}/><Select label="Department" required value={form.department_id} onChange={e=>setForm({...form,department_id:e.target.value})}><option value="">Select department</option>{departments.filter(d=>d.is_active).map(d=><option key={d.id} value={d.id}>{d.name}</option>)}</Select>{error&&<div className="rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700">{error}</div>}<div className="flex justify-end gap-2"><Button type="button" variant="outline" onClick={onClose}>Cancel</Button><Button disabled={busy} variant="success">{busy?"Saving…":"Save Changes"}</Button></div></form></Modal>
}

function UsersTab({users,filter,setFilter,onAdd,onImport,onEdit,onDelete}){
 const rows=users.filter(u=>u.category==="FIELD_STUDENT"&&(filter==="ALL"||u.category===filter));
 return <div className="space-y-5">
  <div className="flex flex-wrap items-end justify-between gap-3">
   <div><h1 className="text-2xl font-black">User Management</h1><p className="text-sm text-slate-500">Create, edit and deactivate Field Student accounts. Student IDs are generated automatically.</p></div>
   <div className="flex flex-wrap gap-2">
    <label className="inline-flex cursor-pointer items-center gap-2 rounded-xl bg-slate-800 px-4 py-2.5 text-sm font-bold text-white"><FileUp size={16}/> Import Excel/CSV<input type="file" accept=".csv,.xlsx,.xls" className="hidden" onChange={onImport}/></label>
    <Button variant="success" onClick={onAdd}><UserPlus size={16}/> Add User</Button>
   </div>
  </div>
  <Card className="overflow-hidden">
   <div className="flex justify-end p-4"><Select label="Category" value={filter} onChange={e=>setFilter(e.target.value)}><option value="ALL">All</option><option value="FIELD_STUDENT">Field Students</option></Select></div>
   <div className="overflow-x-auto">
    <table className="w-full min-w-[900px] text-left text-sm">
     <thead className="bg-slate-50 text-xs uppercase text-slate-500"><tr>
      <th className="px-5 py-3">Name</th><th className="px-5 py-3">ID</th><th className="px-5 py-3">Category</th><th className="px-5 py-3">Department</th><th className="px-5 py-3">Email</th><th className="px-5 py-3">Status</th><th className="px-5 py-3">Actions</th>
     </tr></thead>
     <tbody className="divide-y">
      {rows.map(u=><tr key={u.id}>
       <td className="px-5 py-3 font-semibold">{u.full_name}</td><td className="px-5 py-3">{u.user_code}</td>
       <td className="px-5 py-3"><Badge tone="blue">Field Student</Badge></td>
       <td className="px-5 py-3">{u.department||departments.find(d=>d.id===u.department_id)?.name||"—"}</td><td className="px-5 py-3">{u.official_email}</td>
       <td className="px-5 py-3"><Badge tone={u.is_active?"green":"red"}>{u.is_active?"Active":"Disabled"}</Badge></td>
       <td className="px-5 py-3"><div className="flex gap-2">
        {u.is_active&&<Button onClick={()=>onEdit(u)}>Edit</Button>}
        {u.is_active&&<Button variant="danger" onClick={()=>onDelete(u)}>Delete</Button>}
       </div></td>
      </tr>)}
      {rows.length===0&&<tr><td colSpan="7" className="px-5 py-10 text-center text-slate-500">No members found.</td></tr>}
     </tbody>
    </table>
   </div>
  </Card>
 </div>
}
function DepartmentsTab({departments,users,onAdd,onAdmin,onRefresh}){return <div className="space-y-5"><div className="flex flex-wrap items-center justify-between gap-3"><div><h1 className="text-2xl font-black">Departments & Department Admins</h1><p className="text-sm text-slate-500">Create departments and assign one administrator to manage each department.</p></div><div className="flex flex-wrap gap-2"><Button variant="outline" onClick={onAdd}><Building2 size={16}/> Register Department</Button><Button variant="success" onClick={onAdmin}><ShieldCheck size={16}/> Register Department Admin</Button></div></div><Card className="overflow-hidden"><div className="overflow-x-auto"><table className="w-full min-w-[700px] text-left text-sm"><thead className="bg-slate-50 text-xs uppercase text-slate-500"><tr><th className="px-5 py-3">Department</th><th className="px-5 py-3">Status</th><th className="px-5 py-3">Members</th><th className="px-5 py-3">Department Admin</th></tr></thead><tbody className="divide-y">{departments.map(d=>{const admins=users.filter(u=>u.category==="DEPARTMENT_ADMIN"&&u.department_id===d.id);const memberCount=users.filter(u=>u.department_id===d.id&&["FIELD_STUDENT"].includes(u.category)).length;return <tr key={d.id}><td className="px-5 py-3 font-semibold">{d.name}</td><td className="px-5 py-3"><Badge tone={d.is_active?"green":"red"}>{d.is_active?"Active":"Disabled"}</Badge></td><td className="px-5 py-3">{memberCount}</td><td className="px-5 py-3">{admins.length?admins.map(a=>a.full_name).join(", "):"Not assigned"}</td></tr>})}{!departments.length&&<tr><td colSpan="4" className="px-5 py-10 text-center text-slate-500">No departments registered yet.</td></tr>}</tbody></table></div></Card><Button variant="outline" onClick={onRefresh}>Refresh</Button></div>}
function LeaveTab({rows,reload,isDeptAdmin}){async function action(id,status){try{const{error}=await supabase.functions.invoke("leave-approval",{body:{request_id:id,status}});if(error)throw error;reload()}catch(e){alert(e.message||"Unable to review leave request.")}}return <div className="space-y-5"><div><h1 className="text-2xl font-black">Leave Management</h1><p className="text-sm text-slate-500">{isDeptAdmin?"Review leave requests submitted by members of your department.":"Review all leave requests."}</p></div><Card className="overflow-hidden"><div className="overflow-x-auto"><table className="w-full text-left text-sm"><thead className="bg-slate-50 text-xs uppercase text-slate-500"><tr><th className="px-5 py-3">User</th><th className="px-5 py-3">Type</th><th className="px-5 py-3">Dates</th><th className="px-5 py-3">Status</th><th className="px-5 py-3">Action</th></tr></thead><tbody className="divide-y">{rows.map(r=><tr key={r.id}><td className="px-5 py-3"><b>{r.profiles?.full_name}</b><div className="text-xs text-slate-500">{r.profiles?.user_code}</div></td><td className="px-5 py-3">{String(r.leave_type).replaceAll("_"," ")}</td><td className="px-5 py-3">{r.start_date} → {r.end_date}</td><td className="px-5 py-3"><Badge tone={r.status==="APPROVED"?"green":r.status==="REJECTED"?"red":"amber"}>{r.status}</Badge></td><td className="px-5 py-3">{r.status==="PENDING"&&<div className="flex gap-2"><Button variant="success" onClick={()=>action(r.id,"APPROVED")}><CheckCircle2 size={15}/> Approve</Button><Button variant="danger" onClick={()=>action(r.id,"REJECTED")}><XCircle size={15}/> Reject</Button></div>}</td></tr>)}{!rows.length&&<tr><td colSpan="5" className="px-5 py-10 text-center text-slate-500">No leave requests found.</td></tr>}</tbody></table></div></Card></div>}
function DailyAttendancePrint({date,rows}){return <div className="daily-attendance-print">
 <div className="print-header"><img src="/icons/tcc-logo.png" alt="Tanga City Council"/><div><h1>TANGA CITY COUNCIL</h1><h2>TCC ATTENDANCE REPORT</h2><p>Date: {date}</p></div></div>
 <table><thead><tr><th>#</th><th>Name</th><th>ID</th><th>Category</th><th>Department</th><th>Sign In</th><th>Sign Out</th><th>Status</th><th>Location</th></tr></thead><tbody>
 {rows.map((x,i)=>{const status=x.onLeave?"On Leave":x.ci?(x.ci.status==="LATE"?"Late":"Present"):"Absent";const location=x.ci?"Within":"-";const tm=v=>v?new Date(v).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}):"-";return <tr key={x.u.id}><td>{i+1}</td><td>{x.u.full_name}</td><td>{x.u.user_code}</td><td>Field Student</td><td>{x.u.department||"-"}</td><td>{tm(x.ci?.captured_at)}</td><td>{tm(x.co?.captured_at)}</td><td>{status}</td><td>{location}</td></tr>})}
 </tbody></table>
 <div className="print-footer"><span>Prepared by: TCC Attendance System</span><span>Daily Attendance Report</span></div>
 </div>}

function Reports({exportRows,onPrint,departments,departmentId,setDepartmentId,fixedDepartment}){return <div className="space-y-5"><div><h1 className="text-2xl font-black">Reports & Export</h1><p className="text-sm text-slate-500">Generate field student attendance reports by department and date.</p></div><Card className="p-5"><Select label="Department" value={departmentId||"ALL"} onChange={e=>setDepartmentId(e.target.value)} disabled={fixedDepartment}><option value="ALL">All Departments</option>{departments.filter(d=>d.is_active).map(d=><option key={d.id} value={d.id}>{d.name}</option>)}</Select></Card><div className="grid gap-4 md:grid-cols-3">{[["FIELD_STUDENT","Field Student Attendance Report"],["ALL","Combined Attendance Summary"]].map(([k,l])=><Card className="p-5" key={k}><h2 className="font-black">{l}</h2><p className="mt-2 text-sm text-slate-500">Export CSV for Excel or generate a formatted attendance PDF.</p><div className="mt-5 flex flex-wrap gap-2"><Button onClick={()=>exportRows(k,departmentId)}><Download size={16}/> CSV</Button><Button variant="outline" onClick={()=>onPrint(k)}>Print/PDF</Button></div></Card>)}</div></div>}
function ReportSelector({open,onClose,mode,setMode,date,setDate,departments,departmentId,setDepartmentId,fixedDepartment,onGenerate}){if(!open)return null;return <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-sm"><div className="w-full max-w-lg rounded-3xl bg-white p-5 shadow-2xl sm:p-7"><div className="flex items-start justify-between gap-4"><div><div className="text-xs font-black uppercase tracking-[0.18em] text-emerald-600">Report Builder</div><h2 className="mt-1 text-2xl font-black text-slate-900">Choose report details</h2><p className="mt-1 text-sm text-slate-500">Choose the department and period for this attendance report.</p></div><button onClick={onClose} className="rounded-full bg-slate-100 px-3 py-2 text-lg font-bold text-slate-600">×</button></div><div className="mt-5"><Select label="Department" value={departmentId||"ALL"} onChange={e=>setDepartmentId(e.target.value)} disabled={fixedDepartment}><option value="ALL">All Departments</option>{departments.filter(d=>d.is_active).map(d=><option key={d.id} value={d.id}>{d.name}</option>)}</Select></div><div className="mt-6 grid gap-3 sm:grid-cols-3">{[["ALL","All Records","Complete attendance history"],["TODAY","Today","Attendance for today"],["DATE","One Date","Choose a specific day"]].map(([v,t,d])=><button key={v} onClick={()=>setMode(v)} className={`rounded-2xl border p-4 text-left transition ${mode===v?"border-emerald-500 bg-emerald-50 ring-2 ring-emerald-200":"border-slate-200 bg-white hover:border-slate-300"}`}><div className="flex items-center justify-between"><span className={`h-4 w-4 rounded-full border-2 ${mode===v?"border-emerald-600 bg-emerald-600":"border-slate-300"}`}></span><span className="text-[10px] font-black uppercase text-slate-400">{v}</span></div><div className="mt-3 font-black text-slate-900">{t}</div><div className="mt-1 text-xs leading-5 text-slate-500">{d}</div></button>)}</div>{mode==="DATE"&&<div className="mt-5 rounded-2xl bg-slate-50 p-4"><label className="text-sm font-bold text-slate-700">Report date</label><input type="date" value={date} max={localDate()} onChange={e=>setDate(e.target.value)} className="mt-2 w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-base font-semibold outline-none focus:border-emerald-500"/></div>}<div className="mt-6 flex justify-end gap-2"><Button variant="outline" onClick={onClose}>Cancel</Button><Button onClick={onGenerate}>Generate Report</Button></div></div></div>}
function Settings({settings,updateRadius,setMsg}){const setCurrent=async()=>{setMsg("Getting current device location...");try{const pos=await getBestPosition({onStatus:setMsg});const hq_lat=Number(pos.coords.latitude),hq_lng=Number(pos.coords.longitude);const{error}=await supabase.from("app_settings").update({hq_lat,hq_lng}).eq("id",true);if(error)throw error;setMsg("Attendance center updated to this device location.");window.location.reload()}catch(e){setMsg(`Location error: ${e.message||"Unable to get your location."}`)}};return <div className="space-y-5"><h1 className="text-2xl font-black">Security & Geofence Settings</h1><Card className="max-w-xl p-5"><h2 className="font-black">Attendance Center</h2><p className="mt-1 text-sm text-slate-500">{settings?.hq_lat?.toFixed?.(6)}, {settings?.hq_lng?.toFixed?.(6)}</p><button onClick={setCurrent} className="mt-3 inline-flex items-center gap-2 rounded-xl bg-[#0b1f3a] px-4 py-2.5 text-sm font-bold text-white"><Navigation size={16}/> Use Current Device Location</button><div className="mt-5 grid grid-cols-3 gap-2 sm:grid-cols-5">{[100,200,300,400,500].map(x=><button key={x} onClick={()=>updateRadius(x)} className={`rounded-xl border p-4 font-black ${settings?.geofence_radius_m===x?"border-blue-700 bg-blue-50 text-blue-700":"border-slate-200 bg-white"}`}>{x}m</button>)}</div><div className="mt-5 rounded-xl bg-slate-50 p-4 text-sm">Late threshold: <b>07:30 AM</b><br/>GPS accuracy is used for location verification.<br/>Daily state resets at midnight.</div></Card></div>}
