# GPS FIX FINAL

Frontend GPS handling was hardened for Android/mobile browsers.

- Added shared `client/src/lib/gps.js` helper.
- Tries recent network location, then fresh high-accuracy GPS, then `watchPosition` fallback.
- Uses clear permission/unavailable/timeout messages.
- Updated Field Student Sign In/Sign Out to use the shared helper.
- Updated Admin Security & Geofence Settings -> Use Current Device Location.
- Updated Attendance Area map live-location lookup to use the same helper.

IMPORTANT: Do not deploy/replace the Supabase Edge Functions from this ZIP. The live Supabase `attendance` function already contains the 500m sign-in / 600m sign-out rule. This ZIP is intended for the frontend/Vercel deployment.
