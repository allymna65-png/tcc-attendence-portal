# V24 Fixes

- Replaced the browser prompt used for report selection with a modern in-page report builder.
- Report period is selected directly inside the application.
- Options: All Records, Today, One Date.
- One Date uses a native date picker and prevents future dates.
- The selected report category (Staff, Field Students, or Combined) is preserved.
- The existing report generation and PDF layout remain unchanged.
- No other system behavior was intentionally changed.
