# Production Deployment Checklist

## 1. Supabase
1. Create/open the Supabase project.
2. Run `supabase/migrations/001_tcc_schema.sql`.
3. Deploy each Edge Function:
   - bootstrap-admin
   - admin-users
   - password-reset-approval
   - attendance
   - leave-overdue
4. Set Edge Function secrets:
   - SUPABASE_URL
   - SUPABASE_SERVICE_ROLE_KEY
5. In Auth > URL Configuration:
   - Site URL: production Vercel URL
   - Redirect URLs: production URL and `https://*.vercel.app/**` if desired.

## 2. Frontend
Create `client/.env`:
```
VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=YOUR_PUBLISHABLE_KEY
```

## 3. Vercel
Deploy the repository root. `vercel.json` already defines the build and output.

## 4. First login
If there are zero HR Admin profiles, the setup page is displayed.
Create the primary HR Admin and verify the email.
After the first admin exists, public setup is permanently unavailable.

## 5. Production tests
- First admin setup
- Admin login
- Field Student creation
- Student creation
- Default password reset
- ID login
- Geofence inside/outside
- GPS accuracy is displayed for reference
- Check-in then check-out
- Duplicate check-in/out rejection
- Offline queue and sync
- Leave request and approval
- Overdue leave alert
- CSV/XLSX import
- CSV export and print/PDF
- PWA installation


## V3 deployment settings
If deploying by Vercel Drop:
- Upload the project root folder (the folder containing `vercel.json`, `client/`, and `supabase/`).
- Do not upload only `client/`.
- Do not set Root Directory to `client` when using this `vercel.json`.
- The project contains a public Supabase publishable key fallback so the frontend can boot even if Vercel environment variables were not entered.
- Never add the Supabase service-role key to Vercel frontend variables.


## V4 important
The Supabase production database has been reset to zero application users.
After V4 is deployed, the first screen must be:
Initial Setup: Create Primary HR Admin
After the first admin is created, public admin registration is permanently disabled.
Do not create an admin manually in the profiles table; use the setup screen.
The location displayed by the UI is TCC Attendance

## V5 password-reset fix
Field Students cannot directly update profiles because profiles are admin-write protected. Mandatory password reset now uses public.complete_password_reset(uid), which verifies auth.uid() server-side and only changes must_reset_password.


## V6 GPS/offline fix
The browser no longer queues attendance when the internet is available but the server rejects the request (for example, because the user is outside the geofence or GPS accuracy is too poor).
It queues only when the device is actually offline. The portal also shows live IN BOUNDS / OUT OF BOUNDS / UNTRUSTED GPS status.


## V7 Admin member management
HR Admin can edit Field Student profile details and deactivate member accounts. HR Admin accounts are protected from this flow.
