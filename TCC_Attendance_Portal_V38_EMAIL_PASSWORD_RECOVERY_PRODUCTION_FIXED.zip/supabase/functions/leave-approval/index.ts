import {corsHeaders,json} from "./_shared/cors.ts";
import {adminClient,requireManagementAdmin} from "./_shared/client.ts";

Deno.serve(async req=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:corsHeaders});
 try{
  const {admin,user,profile:actor}=await requireManagementAdmin(req);
  const b=await req.json();
  const id=String(b.request_id||"");
  const status=String(b.status||"").toUpperCase();
  if(!id||!["APPROVED","REJECTED"].includes(status))throw new Error("Invalid leave action.");
  const {data:r,error:re}=await admin.from("leave_requests").select("id,user_id,status,leave_type,start_date,end_date,profiles(full_name,user_code,department_id)").eq("id",id).single();
  if(re||!r)throw new Error("Leave request not found.");
  if(r.status!=="PENDING")throw new Error("Leave request already reviewed.");
  const targetDepartment=r.profiles?.department_id||null;
  if(actor.category==="DEPARTMENT_ADMIN"&&targetDepartment!==actor.department_id)throw new Error("You can only review leave requests from your own department.");
  const {data:updated,error}=await admin.from("leave_requests").update({status,approved_by:status==="APPROVED"?user.id:null,approved_at:new Date().toISOString()}).eq("id",id).eq("status","PENDING").select("*").single();
  if(error)throw error;
  await admin.from("audit_logs").insert({actor_id:user.id,target_user_id:r.user_id,action:status==="APPROVED"?"LEAVE_APPROVED":"LEAVE_REJECTED",metadata:{request_id:id,reviewer_role:actor.category}});
  await admin.from("notifications").insert({user_id:r.user_id,title:status==="APPROVED"?"Leave Approved":"Leave Rejected",message:status==="APPROVED"?`Your ${r.leave_type.replaceAll("_"," ").toLowerCase()} leave request was approved by ${actor.category==="DEPARTMENT_ADMIN"?"your Department Admin":"HR Admin"}.`:`Your ${r.leave_type.replaceAll("_"," ").toLowerCase()} leave request was rejected by ${actor.category==="DEPARTMENT_ADMIN"?"your Department Admin":"HR Admin"}.`,type:status==="APPROVED"?"SUCCESS":"WARNING"});
  return json({ok:true,request:updated});
 }catch(e){return json({error:e?.message||String(e)},400)}
});
