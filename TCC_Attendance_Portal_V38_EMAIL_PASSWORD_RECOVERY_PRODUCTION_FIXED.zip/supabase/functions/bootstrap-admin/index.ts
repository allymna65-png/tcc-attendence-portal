import {corsHeaders,json} from "./_shared/cors.ts";
import {adminClient} from "./_shared/client.ts";

Deno.serve(async req=>{
 if(req.method==="OPTIONS") return new Response("ok",{headers:corsHeaders});
 try{
  const admin=adminClient();
  const body=await req.json();
  const {count}=await admin.from("profiles").select("id",{count:"exact",head:true}).eq("category","HR_ADMIN");
  if((count||0)>0) throw new Error("Primary HR Admin already exists. Public bootstrap is permanently disabled.");
  if(!body.full_name||!body.official_email||!body.phone||!body.password) throw new Error("Full name, email, phone and password are required.");
  const {data,error}=await admin.auth.admin.createUser({email:body.official_email,password:body.password,email_confirm:true,user_metadata:{full_name:body.full_name,phone:body.phone,category:"HR_ADMIN"}});
  if(error) throw error;
  const {data:profile,error:pe}=await admin.from("profiles").update({full_name:body.full_name,official_email:body.official_email,phone:body.phone,category:"HR_ADMIN",must_reset_password:false,is_active:true}).eq("id",data.user.id).select("*").single();
  if(pe){await admin.auth.admin.deleteUser(data.user.id);throw pe;}
  return json({profile});
 }catch(e){return json({error:e.message},400)}
});
