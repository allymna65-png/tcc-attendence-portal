import {corsHeaders,json} from "./_shared/cors.ts";
import {adminClient,requireAdmin} from "./_shared/client.ts";

Deno.serve(async req=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:corsHeaders});
 try{
  const {admin}=await requireAdmin(req);
  const now=new Date(), today=new Intl.DateTimeFormat("en-CA",{timeZone:"Africa/Dar_es_Salaam",year:"numeric",month:"2-digit",day:"2-digit"}).format(now);
  const {data:approved}=await admin.from("leave_requests").select("*,profiles(full_name,user_code,category)").eq("status","APPROVED").lt("end_date",today);
  const alerts=[];
  for(const l of approved||[]){
    const {count}=await admin.from("attendance_records").select("id",{count:"exact",head:true}).eq("user_id",l.user_id).eq("attendance_date",today).eq("action","CHECK_IN");
    if((count||0)===0)alerts.push({user_id:l.user_id,full_name:l.profiles?.full_name,user_code:l.profiles?.user_code,end_date:l.end_date});
  }
  return json({today,alerts});
 }catch(e){return json({error:e.message},400)}
});
