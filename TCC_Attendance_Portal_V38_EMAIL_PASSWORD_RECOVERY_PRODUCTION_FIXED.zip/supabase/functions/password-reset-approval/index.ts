import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { corsHeaders, json } from "./_shared/cors.ts";

const DEFAULTS: Record<string, string> = {
  FIELD_STUDENT: "STD_123456",
  DEPARTMENT_ADMIN: "ADMN_123457",
};

function adminClient() {
  return createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    { auth: { autoRefreshToken: false, persistSession: false } },
  );
}

function userClient(req: Request) {
  return createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_ANON_KEY")!,
    {
      auth: { autoRefreshToken: false, persistSession: false },
      global: {
        headers: {
          Authorization: req.headers.get("Authorization") || "",
        },
      },
    },
  );
}

async function getCaller(req: Request) {
  const auth = req.headers.get("Authorization") || "";
  const token = auth.replace(/^Bearer\s+/i, "").trim();
  if (!token) throw new Error("Missing Authorization. Please sign in again.");

  // verify_jwt=true validates the bearer JWT at the Supabase gateway.
  // Use a user-scoped client here so Auth validates the same request token.
  const client = userClient(req);
  const { data, error } = await client.auth.getUser(token);
  if (error || !data.user) {
    throw new Error("Your session has expired. Please sign in again and retry.");
  }
  return data.user;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const user = await getCaller(req);
    const admin = adminClient();

    const profileResult = await admin
      .from("profiles")
      .select("id,category,full_name,user_code,official_email,is_active")
      .eq("id", user.id)
      .single();

    if (profileResult.error || !profileResult.data) {
      throw new Error("Your user profile could not be found.");
    }
    if (!profileResult.data.is_active || profileResult.data.category !== "HR_ADMIN") {
      throw new Error("HR Admin access required.");
    }

    const body = await req.json().catch(() => ({}));
    const requestId = String(body?.request_id || "").trim();
    if (!requestId) throw new Error("Reset request ID is required.");

    const { data: request, error: requestError } = await admin
      .from("password_reset_requests")
      .select("*,profiles!password_reset_requests_user_id_fkey(category,full_name,user_code,official_email)")
      .eq("id", requestId)
      .single();

    if (requestError || !request) {
      throw new Error(requestError?.message || "Reset request not found.");
    }
    if (request.status !== "PENDING") throw new Error("Request already reviewed.");

    const category = request.profiles?.category as string | undefined;
    const password = category ? DEFAULTS[category] : undefined;
    if (!password) throw new Error("This account type cannot be reset from this queue.");

    const { error: authError } = await admin.auth.admin.updateUserById(request.user_id, { password });
    if (authError) throw new Error(`Unable to reset account password: ${authError.message}`);

    const { error: profileError } = await admin
      .from("profiles")
      .update({ must_reset_password: true, updated_at: new Date().toISOString() })
      .eq("id", request.user_id);
    if (profileError) throw new Error(`Password reset succeeded but profile update failed: ${profileError.message}`);

    const { error: reviewError } = await admin
      .from("password_reset_requests")
      .update({
        status: "APPROVED",
        reviewed_by: user.id,
        reviewed_at: new Date().toISOString(),
      })
      .eq("id", request.id);
    if (reviewError) throw new Error(`Password reset succeeded but request update failed: ${reviewError.message}`);

    await admin.from("notifications").insert({
      user_id: request.user_id,
      title: "Password Reset Approved",
      message: "Your password reset request was approved. Sign in using the default password provided by the administrator, then create a new strong password.",
      type: "SUCCESS",
    });

    return json({
      ok: true,
      default_password: password,
      user: {
        id: request.user_id,
        full_name: request.profiles?.full_name,
        user_code: request.profiles?.user_code,
      },
    });
  } catch (e) {
    const message = e instanceof Error ? e.message : String(e);
    return json({ error: message }, 400);
  }
});
