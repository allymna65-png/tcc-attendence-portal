import {corsHeaders,json} from "./_shared/cors.ts";
import {adminClient,requireManagementAdmin} from "./_shared/client.ts";
Deno.serve(async req=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:corsHeaders});
 try{
  const {admin,profile}=await requireManagementAdmin(req);
  const type=String((await req.json()).type||"").toUpperCase();
  const scope=profile.category==="DEPARTMENT_ADMIN"?profile.department_id:null;
  if(type==="LEAVE"){
   const {data,error}=await admin.from("leave_requests").select("*,profiles(full_name,user_code,category,department,department_id)").order("created_at",{ascending:false});
   if(error)throw error;
   const items=scope?(data||[]).filter(x=>x.profiles?.department_id===scope):(data||[]);
   return json({ok:true,items});
  }
  if(type==="RESET"){
   const {data,error}=await admin.from("password_reset_requests").select("*,profiles(full_name,user_code,category,department,department_id)").order("created_at",{ascending:false});
   if(error)throw error;
   const items=scope?(data||[]).filter(x=>x.profiles?.department_id===scope):(data||[]);
   return json({ok:true,items});
  }
  throw new Error("Invalid queue type.");
 }catch(e){return json({error:e?.message||String(e)},400)}
});
