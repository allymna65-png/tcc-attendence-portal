import {corsHeaders,json} from "./_shared/cors.ts";
import {adminClient,requireUser} from "./_shared/client.ts";

Deno.serve(async req=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:corsHeaders});
 try{
  const {admin,user}=await requireUser(req);
  const b=await req.json();
  const leave_type=String(b.leave_type||"").toUpperCase();
  const start_date=String(b.start_date||"");
  const end_date=String(b.end_date||"");
  const reason=String(b.reason||"").trim();
  if(!["SICK","OFFICIAL_PERMISSION","EMERGENCY"].includes(leave_type))throw new Error("Invalid leave type.");
  if(!start_date||!end_date||end_date<start_date)throw new Error("Valid leave dates are required.");
  if(!reason)throw new Error("Leave reason is required.");
  const {data:profile,error:pe}=await admin.from("profiles").select("id,full_name,user_code,category,is_active,department_id,department").eq("id",user.id).single();
  if(pe||!profile?.is_active||profile.category!=="FIELD_STUDENT")throw new Error("Active field student profile required.");
  const {data:existing}=await admin.from("leave_requests").select("id").eq("user_id",user.id).eq("status","PENDING").maybeSingle();
  if(existing)throw new Error("You already have a pending leave request.");
  const {data:request,error}=await admin.from("leave_requests").insert({user_id:user.id,leave_type,start_date,end_date,reason,status:"PENDING"}).select("*").single();
  if(error)throw error;
  const {data:admins,error:ae}=await admin.from("profiles").select("id,category,department_id").eq("is_active",true).in("category",["HR_ADMIN","DEPARTMENT_ADMIN"]);
  if(ae)throw ae;
  const recipients=(admins||[]).filter(a=>a.category==="HR_ADMIN"||(profile.department_id&&a.department_id===profile.department_id));
  if(recipients.length)await admin.from("notifications").insert(recipients.map(a=>({user_id:a.id,title:"New Leave Request",message:`${profile.full_name} (${profile.user_code}) submitted a ${leave_type.replaceAll("_"," ").toLowerCase()} request from ${start_date} to ${end_date}.`,type:"INFO"})));
  return json({ok:true,request});
 }catch(e){return json({error:e?.message||String(e)},400)}
});
