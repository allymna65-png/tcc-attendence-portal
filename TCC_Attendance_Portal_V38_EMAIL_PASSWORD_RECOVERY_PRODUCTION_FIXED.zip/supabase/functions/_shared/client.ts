import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
export function adminClient(){
  return createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,{auth:{autoRefreshToken:false,persistSession:false}});
}
export async function requireUser(req:Request){
  const auth=req.headers.get("Authorization")||"";
  const token=auth.replace(/^Bearer\s+/i,"");
  if(!token) throw new Error("Missing Authorization");
  const admin=adminClient();
  const {data,error}=await admin.auth.getUser(token);
  if(error||!data.user) throw new Error("Invalid session");
  return {admin,user:data.user};
}
export async function requireAdmin(req:Request){
  const {admin,user}=await requireUser(req);
  const {data:p,error}=await admin.from("profiles").select("*").eq("id",user.id).single();
  if(error||p?.category!=="HR_ADMIN"||!p.is_active) throw new Error("HR Admin access required");
  return {admin,user,profile:p};
}
export async function requireManagementAdmin(req:Request){
  const {admin,user}=await requireUser(req);
  const {data:p,error}=await admin.from("profiles").select("*").eq("id",user.id).single();
  if(error||!p?.is_active||!["HR_ADMIN","DEPARTMENT_ADMIN"].includes(p.category)) throw new Error("Administrator access required");
  return {admin,user,profile:p};
}
