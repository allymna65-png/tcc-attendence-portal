import {corsHeaders,json} from "./_shared/cors.ts";
import {adminClient} from "./_shared/client.ts";

Deno.serve(async req=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:corsHeaders});
 try{
  const admin=adminClient();
  const body=await req.json();
  const identifier=String(body.identifier||"").trim().toLowerCase();
  const reason=String(body.reason||"").trim();
  if(!identifier)throw new Error("Email or ID is required.");
  const {data:profile,error}=identifier.includes("@")
    ? await admin.from("profiles").select("id,full_name,user_code,category,is_active,department_id").eq("official_email",identifier).maybeSingle()
    : await admin.from("profiles").select("id,full_name,user_code,category,is_active,department_id").eq("user_code",identifier).maybeSingle();
  if(error||!profile||!profile.is_active||profile.category==="HR_ADMIN")throw new Error("Account not found.");
  const {data:existing}=await admin.from("password_reset_requests").select("id").eq("user_id",profile.id).eq("status","PENDING").maybeSingle();
  if(existing)throw new Error("A reset request is already pending for this account.");
  const {data,error:insertError}=await admin.from("password_reset_requests").insert({user_id:profile.id,reason}).select("id,status,created_at").single();
  if(insertError)throw insertError;
  const {data:admins,error:ae}=await admin.from("profiles").select("id,category,department_id").eq("is_active",true).in("category",["HR_ADMIN","DEPARTMENT_ADMIN"]);
  if(ae)throw ae;
  const recipients=(admins||[]).filter(a=>a.category==="HR_ADMIN"||(profile.department_id&&a.department_id===profile.department_id));
  if(recipients.length)await admin.from("notifications").insert(recipients.map(a=>({user_id:a.id,title:"New Password Reset Request",message:`${profile.full_name} (${profile.user_code}) requested a password reset.`,type:"WARNING"})));
  return json({ok:true,request:data});
 }catch(e){return json({error:e?.message||String(e)},400)}
});
