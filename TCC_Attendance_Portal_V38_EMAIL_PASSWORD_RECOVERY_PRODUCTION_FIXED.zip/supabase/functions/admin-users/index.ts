import {corsHeaders,json} from "./_shared/cors.ts";
import {adminClient,requireManagementAdmin} from "./_shared/client.ts";

const STUDENT_DEFAULT="STD_123456";
const DEPARTMENT_ADMIN_DEFAULT="ADMN_123457";
function normalize(x:any){
 return {full_name:String(x.full_name||"").trim(),category:"FIELD_STUDENT",department_id:x.department_id||null,department:String(x.department||"").trim(),official_email:String(x.official_email||"").trim().toLowerCase()};
}
async function createOne(admin:any,x:any,actor:any){
 const u=normalize(x);
 if(!u.full_name||!u.official_email||!u.department_id) throw new Error("Full name, email and department are required. Student ID is generated automatically.");
 if(!/^\S+@\S+\.\S+$/.test(u.official_email)) throw new Error("A valid official email is required.");
 if(actor.category==="DEPARTMENT_ADMIN"&&u.department_id!==actor.department_id) throw new Error("You can only register members in your own department.");
 const {data:dept,error:de}=await admin.from("departments").select("id,name,is_active").eq("id",u.department_id).single();
 if(de||!dept?.is_active) throw new Error("Selected department is not available.");
 const password=STUDENT_DEFAULT;
 const {data,error}=await admin.auth.admin.createUser({email:u.official_email,password,email_confirm:true,user_metadata:{full_name:u.full_name,phone:"",category:u.category,must_reset_password:true}});
 if(error) throw error;
 const {error:pe}=await admin.from("profiles").upsert({id:data.user.id,full_name:u.full_name,category:"FIELD_STUDENT",department:dept.name,department_id:u.department_id,official_email:u.official_email,must_reset_password:true,is_active:true,phone:""},{onConflict:"id"});
 if(pe){await admin.auth.admin.deleteUser(data.user.id);throw pe;}
 const {data:profile}=await admin.from("profiles").select("user_code").eq("id",data.user.id).single();
 return {full_name:u.full_name,user_code:profile?.user_code||"",department:dept.name,default_password:password};
}
async function createDepartmentAdmin(admin:any,x:any,actor:any){
 if(actor.category!=="HR_ADMIN") throw new Error("Only the Primary HR Admin can create Department Admins.");
 const full_name=String(x.full_name||"").trim(),official_email=String(x.official_email||"").trim().toLowerCase(),department_id=x.department_id||null;
 if(!full_name||!official_email||!department_id) throw new Error("Full name, email and department are required. Admin ID is generated automatically.");
 if(!/^\S+@\S+\.\S+$/.test(official_email)) throw new Error("A valid official email is required.");
 const {data:dept,error:de}=await admin.from("departments").select("id,name,is_active").eq("id",department_id).single();
 if(de||!dept?.is_active) throw new Error("Selected department is not available.");
 const {data:existing}=await admin.from("profiles").select("id,full_name").eq("category","DEPARTMENT_ADMIN").eq("department_id",department_id).eq("is_active",true).limit(1);
 if(existing?.length) throw new Error(`This department already has a Department Admin: ${existing[0].full_name}.`);
 const password=DEPARTMENT_ADMIN_DEFAULT;
 const {data,error}=await admin.auth.admin.createUser({email:official_email,password,email_confirm:true,user_metadata:{full_name,phone:"",category:"DEPARTMENT_ADMIN",must_reset_password:true}});
 if(error) throw error;
 const {error:pe}=await admin.from("profiles").upsert({id:data.user.id,full_name,category:"DEPARTMENT_ADMIN",department:dept.name,department_id,official_email,must_reset_password:true,is_active:true,phone:""},{onConflict:"id"});
 if(pe){await admin.auth.admin.deleteUser(data.user.id);throw pe;}
 const {data:profile}=await admin.from("profiles").select("user_code").eq("id",data.user.id).single();
 return {full_name,user_code:profile?.user_code||"",department:dept.name,default_password:password};
}
Deno.serve(async req=>{
 if(req.method==="OPTIONS") return new Response("ok",{headers:corsHeaders});
 try{
  const {admin,profile}=await requireManagementAdmin(req); const body=await req.json();
  if(body.action==="create") return json({user:await createOne(admin,body.user,profile)});
  if(body.action==="bulk_create"){
   const created=[],skipped=[];
   for(const raw of (body.users||[])){try{created.push(await createOne(admin,raw,profile))}catch(e){skipped.push({user_code:raw.user_code||"",reason:e.message})}}
   return json({created:created.length,skipped:skipped.length,details:{created,skipped}});
  }
  if(body.action==="create_department_admin") return json({user:await createDepartmentAdmin(admin,body.user,profile)});
  if(body.action==="update"||body.action==="delete"){
   const targetId=body.user_id;
   const {data:target,error:te}=await admin.from("profiles").select("*").eq("id",targetId).single();
   if(te||!target) throw new Error("Member not found.");
   if(profile.category==="DEPARTMENT_ADMIN"&&(target.department_id!==profile.department_id||!["FIELD_STUDENT"].includes(target.category))) throw new Error("You can only manage members in your own department.");
   if(body.action==="delete"){
    const {error}=await admin.from("profiles").update({is_active:false,updated_at:new Date().toISOString()}).eq("id",targetId);if(error)throw error;
    return json({ok:true});
   }
   const department_id=body.department_id||target.department_id;
   if(!department_id) throw new Error("Department is required.");
   if(profile.category==="DEPARTMENT_ADMIN"&&department_id!==profile.department_id) throw new Error("You can only use your own department.");
   const {data:dept,error:de}=await admin.from("departments").select("id,name,is_active").eq("id",department_id).single();if(de||!dept?.is_active)throw new Error("Department is not available.");
   const nextName=String(body.full_name||target.full_name).trim();
   const nextEmail=String(body.official_email||target.official_email).trim().toLowerCase();
   const nextPhone=String(body.phone||target.phone||"").trim();
   if(!nextName||!nextEmail||!/^\S+@\S+\.\S+$/.test(nextEmail)) throw new Error("A valid official email and full name are required.");
   if(nextEmail!==String(target.official_email||"").toLowerCase()){
     const {error:ae}=await admin.auth.admin.updateUserById(targetId,{email:nextEmail,email_confirm:true});
     if(ae)throw ae;
   }
   const {error}=await admin.from("profiles").update({full_name:nextName,official_email:nextEmail,department_id,department:dept.name,phone:nextPhone,updated_at:new Date().toISOString()}).eq("id",targetId);if(error)throw error;
   return json({ok:true});
  }
  throw new Error("Unknown action");
 }catch(e){return json({error:e.message},400)}
});
