import {corsHeaders,json} from "./_shared/cors.ts";
import {adminClient,requireUser} from "./_shared/client.ts";

function haversine(lat1:number,lon1:number,lat2:number,lon2:number){
 const R=6371000,toRad=(x:number)=>x*Math.PI/180,dLat=toRad(lat2-lat1),dLon=toRad(lon2-lon1);
 const a=Math.sin(dLat/2)**2+Math.cos(toRad(lat1))*Math.cos(toRad(lat2))*Math.sin(dLon/2)**2;
 return 2*R*Math.asin(Math.sqrt(a));
}
function localDateTime(now=new Date()){
 const parts=new Intl.DateTimeFormat("en-CA",{timeZone:"Africa/Dar_es_Salaam",year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",second:"2-digit",hourCycle:"h23"}).formatToParts(now);
 const get=(t:string)=>parts.find(p=>p.type===t)?.value||"00";
 return {date:`${get("year")}-${get("month")}-${get("day")}`,time:`${get("hour")}:${get("minute")}:${get("second")}`};
}
Deno.serve(async req=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:corsHeaders});
 try{
  const {admin,user}=await requireUser(req),b=await req.json();
  const {data:p,error:pe}=await admin.from("profiles").select("*").eq("id",user.id).single();if(pe||!p||!p.is_active)throw new Error("Active profile required.");
  if(!["CHECK_IN","CHECK_OUT"].includes(b.type))throw new Error("Invalid attendance action.");
  if(!Number.isFinite(b.latitude)||!Number.isFinite(b.longitude)||!Number.isFinite(b.accuracy_m))throw new Error("Valid GPS data is required.");
  const {data:s,error:se}=await admin.from("app_settings").select("*").single();if(se)throw se;
  const baseRadius=Number(s.geofence_radius_m)||500;const checkoutTolerance=100;const allowedRadius=b.type==="CHECK_OUT"?baseRadius+checkoutTolerance:baseRadius;const distance=haversine(b.latitude,b.longitude,s.hq_lat,s.hq_lng);if(distance>allowedRadius)throw new Error(`${b.type==="CHECK_IN"?"Sign In":"Sign Out"} unavailable: You are out of bounds (${Math.round(distance)}m away; allowed radius is ${allowedRadius}m).`);
  const {date,time}=localDateTime(new Date(b.captured_at||Date.now()));
  const {data:existing}=await admin.from("attendance_records").select("action,device_fingerprint").eq("user_id",user.id).eq("attendance_date",date);
  if(b.type==="CHECK_IN"&&existing?.some(x=>x.action==="CHECK_IN"))throw new Error("Sign In already recorded for today.");
  if(b.type==="CHECK_OUT"&&!existing?.some(x=>x.action==="CHECK_IN"))throw new Error("Sign Out requires a successful Sign In.");
  if(b.type==="CHECK_OUT"&&existing?.some(x=>x.action==="CHECK_OUT"))throw new Error("Sign Out already recorded for today.");
  const status=b.type==="CHECK_IN"?(time<="07:30:00"?"ON_TIME":"LATE"):(b.offline?"OFFLINE_SYNCED":"ON_TIME");
  const {data:row,error}=await admin.from("attendance_records").insert({user_id:user.id,attendance_date:date,action:b.type,captured_at:b.captured_at||new Date().toISOString(),latitude:b.latitude,longitude:b.longitude,accuracy_m:b.accuracy_m,distance_m:distance,status,device_fingerprint:b.device_fingerprint||null,client_event_id:b.client_event_id,synced_at:b.offline?new Date().toISOString():null}).select("*").single();
  if(error){if(error.code==="23505")throw new Error("This attendance event was already synchronized.");throw error;}
  const notificationTitle=b.type==="CHECK_IN"?"Sign In recorded":"Sign Out recorded";
  const notificationMessage=b.type==="CHECK_IN"?(status==="LATE"?"Your Sign In was recorded as Late.":"Your Sign In was recorded successfully."):"Your Sign Out was recorded successfully.";
  await admin.from("notifications").insert({user_id:user.id,title:notificationTitle,message:notificationMessage,type:"SUCCESS"});
  return json({ok:true,message:b.type==="CHECK_IN"?(status==="LATE"?"Sign In recorded as Late.":"Sign In recorded as On Time."):"Sign Out recorded successfully.",record:row});
 }catch(e){return json({error:e.message},400)}
});
