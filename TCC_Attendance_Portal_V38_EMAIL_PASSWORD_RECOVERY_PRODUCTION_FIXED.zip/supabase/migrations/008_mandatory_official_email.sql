-- All TCC accounts must have a verified official email because password recovery is email-based.
update public.profiles p
set official_email = lower(u.email), updated_at = now()
from auth.users u
where p.id = u.id and (p.official_email is null or btrim(p.official_email) = '');

DO $$
BEGIN
  IF EXISTS (select 1 from public.profiles where official_email is null or btrim(official_email) = '') THEN
    RAISE EXCEPTION 'Cannot enforce mandatory email: one or more profiles have no matching Auth email. Update those accounts first.';
  END IF;
END $$;

alter table public.profiles alter column official_email set not null;

-- Keep the profile email aligned with the Auth account for future recovery flows.
create unique index if not exists profiles_official_email_lower_unique_idx
on public.profiles (lower(official_email));
