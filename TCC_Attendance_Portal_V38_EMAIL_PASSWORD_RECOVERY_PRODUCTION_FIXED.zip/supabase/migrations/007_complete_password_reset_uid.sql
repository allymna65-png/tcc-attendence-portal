-- TCC Attendance Portal: mandatory password reset completion RPC compatibility
-- The frontend calls public.complete_password_reset(uid).
create or replace function public.complete_password_reset(uid uuid)
returns uuid
language plpgsql
security definer
set search_path = public, auth
as $$
begin
  if auth.uid() is null or auth.uid() <> uid then
    raise exception 'Not authorized to complete this password reset.';
  end if;

  update public.profiles
  set must_reset_password = false,
      updated_at = now()
  where id = uid;

  if not found then
    raise exception 'Profile not found.';
  end if;

  return uid;
end;
$$;

revoke all on function public.complete_password_reset(uuid) from public;
revoke all on function public.complete_password_reset(uuid) from anon;
grant execute on function public.complete_password_reset(uuid) to authenticated;
notify pgrst, 'reload schema';
