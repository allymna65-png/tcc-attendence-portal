create extension if not exists pgcrypto;

create table if not exists public.app_settings(
  id boolean primary key default true check(id=true),
  hq_lat double precision not null default 0,
  hq_lng double precision not null default 0,
  geofence_radius_m integer not null default 100 check(geofence_radius_m in(50,100,200)),
  late_after time not null default '07:30:00',
  gps_accuracy_limit_m double precision not null default 15,
  updated_at timestamptz not null default now()
);
insert into public.app_settings(id) values(true) on conflict(id) do nothing;

create table if not exists public.profiles(
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  official_email text unique,
  phone text,
  user_code text unique,
  category text not null check(category in('HR_ADMIN','DEPARTMENT_ADMIN','FIELD_STUDENT')),
  department text,
  must_reset_password boolean not null default false,
  is_active boolean not null default true,
  device_fingerprint text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.attendance_records(
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  attendance_date date not null default current_date,
  action text not null check(action in('CHECK_IN','CHECK_OUT')),
  captured_at timestamptz not null default now(),
  latitude double precision not null,
  longitude double precision not null,
  accuracy_m double precision not null,
  distance_m double precision not null,
  status text not null check(status in('ON_TIME','LATE','OFFLINE_SYNCED')),
  device_fingerprint text,
  client_event_id uuid not null,
  synced_at timestamptz,
  created_at timestamptz not null default now(),
  unique(user_id,attendance_date,action),
  unique(user_id,client_event_id)
);

create table if not exists public.leave_requests(
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  leave_type text not null check(leave_type in('SICK','OFFICIAL_PERMISSION','EMERGENCY')),
  start_date date not null,
  end_date date not null,
  reason text,
  status text not null default 'PENDING' check(status in('PENDING','APPROVED','REJECTED')),
  approved_by uuid references public.profiles(id),
  approved_at timestamptz,
  created_at timestamptz not null default now(),
  check(end_date>=start_date)
);

create table if not exists public.password_reset_requests(
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  reason text,
  status text not null default 'PENDING' check(status in('PENDING','APPROVED','REJECTED')),
  reviewed_by uuid references public.profiles(id),
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.audit_logs(
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references public.profiles(id),
  action text not null,
  target_user_id uuid references public.profiles(id),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists attendance_user_date_idx on public.attendance_records(user_id,attendance_date desc);
create index if not exists leave_user_dates_idx on public.leave_requests(user_id,start_date,end_date);
create index if not exists reset_status_idx on public.password_reset_requests(status,created_at desc);

alter table public.app_settings enable row level security;
alter table public.profiles enable row level security;
alter table public.attendance_records enable row level security;
alter table public.leave_requests enable row level security;
alter table public.password_reset_requests enable row level security;
alter table public.audit_logs enable row level security;

create or replace function public.is_hr_admin(uid uuid default auth.uid()) returns boolean
language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.profiles where id=uid and category='HR_ADMIN' and is_active=true);
$$;

drop policy if exists settings_read on public.app_settings;
create policy settings_read on public.app_settings for select to authenticated using(true);
drop policy if exists settings_admin_write on public.app_settings;
create policy settings_admin_write on public.app_settings for update to authenticated using(public.is_hr_admin()) with check(public.is_hr_admin());

drop policy if exists profiles_self_read on public.profiles;
create policy profiles_self_read on public.profiles for select to authenticated using(id=auth.uid() or public.is_hr_admin());
drop policy if exists profiles_admin_update on public.profiles;
create policy profiles_admin_update on public.profiles for update to authenticated using(public.is_hr_admin()) with check(public.is_hr_admin());

drop policy if exists attendance_self_read on public.attendance_records;
create policy attendance_self_read on public.attendance_records for select to authenticated using(user_id=auth.uid() or public.is_hr_admin());
drop policy if exists attendance_admin_manage on public.attendance_records;
create policy attendance_admin_manage on public.attendance_records for update,delete to authenticated using(public.is_hr_admin()) with check(public.is_hr_admin());

drop policy if exists leave_self_read on public.leave_requests;
create policy leave_self_read on public.leave_requests for select to authenticated using(user_id=auth.uid() or public.is_hr_admin());
drop policy if exists leave_self_insert on public.leave_requests;
create policy leave_self_insert on public.leave_requests for insert to authenticated with check(user_id=auth.uid());
drop policy if exists leave_admin_manage on public.leave_requests;
create policy leave_admin_manage on public.leave_requests for update,delete to authenticated using(public.is_hr_admin()) with check(public.is_hr_admin());

drop policy if exists reset_self_read_insert on public.password_reset_requests;
create policy reset_self_read_insert on public.password_reset_requests for select,insert to authenticated using(user_id=auth.uid() or public.is_hr_admin()) with check(user_id=auth.uid() or public.is_hr_admin());
drop policy if exists reset_admin_manage on public.password_reset_requests;
create policy reset_admin_manage on public.password_reset_requests for update,delete to authenticated using(public.is_hr_admin()) with check(public.is_hr_admin());

drop policy if exists audit_admin_read on public.audit_logs;
create policy audit_admin_read on public.audit_logs for select to authenticated using(public.is_hr_admin());

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id,full_name,official_email,phone,category,must_reset_password)
  values(
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name',split_part(coalesce(new.email,''),'@',1)),
    new.email,
    new.raw_user_meta_data->>'phone',
    coalesce(new.raw_user_meta_data->>'category','FIELD_STUDENT'),
    false
  ) on conflict(id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();


create or replace function public.bootstrap_status() returns boolean
language sql stable security definer set search_path=public as $$
  select not exists(select 1 from public.profiles where category='HR_ADMIN');
$$;
grant execute on function public.bootstrap_status() to anon, authenticated;
revoke insert on public.attendance_records from authenticated;
