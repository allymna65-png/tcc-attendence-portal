create table if not exists public.departments(
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

insert into public.departments(name)
select distinct trim(department) from public.profiles
where department is not null and trim(department) <> ''
on conflict(name) do nothing;

alter table public.profiles add column if not exists department_id uuid references public.departments(id);
alter table public.profiles drop constraint if exists profiles_category_check;
alter table public.profiles add constraint profiles_category_check check(category in('HR_ADMIN','DEPARTMENT_ADMIN','FIELD_STUDENT'));

update public.profiles p
set department_id=d.id
from public.departments d
where p.department_id is null and trim(coalesce(p.department,''))=d.name;

alter table public.app_settings drop constraint if exists app_settings_geofence_radius_m_check;
alter table public.app_settings add constraint app_settings_geofence_radius_m_check check(geofence_radius_m between 100 and 500);

create index if not exists profiles_department_idx on public.profiles(department_id);

alter table public.departments enable row level security;
drop policy if exists departments_read on public.departments;
create policy departments_read on public.departments for select to authenticated using(is_active=true or public.is_hr_admin());
drop policy if exists departments_admin_insert on public.departments;
create policy departments_admin_insert on public.departments for insert to authenticated with check(public.is_hr_admin());
drop policy if exists departments_admin_update on public.departments;
create policy departments_admin_update on public.departments for update to authenticated using(public.is_hr_admin()) with check(public.is_hr_admin());
drop policy if exists departments_admin_delete on public.departments;
create policy departments_admin_delete on public.departments for delete to authenticated using(public.is_hr_admin());

create or replace function public.is_department_admin(uid uuid default auth.uid()) returns boolean
language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.profiles where id=uid and category='DEPARTMENT_ADMIN' and is_active=true and department_id is not null);
$$;

create or replace function public.current_department_id(uid uuid default auth.uid()) returns uuid
language sql stable security definer set search_path=public as $$
 select department_id from public.profiles where id=uid and category='DEPARTMENT_ADMIN' and is_active=true limit 1;
$$;

create or replace function public.can_read_department_member(target_id uuid, uid uuid default auth.uid()) returns boolean
language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.profiles target where target.id=target_id and target.department_id=public.current_department_id(uid));
$$;

drop policy if exists profiles_self_read on public.profiles;
drop policy if exists profiles_read_scoped on public.profiles;
create policy profiles_read_scoped on public.profiles for select to authenticated using(
  id=auth.uid()
  or public.is_hr_admin()
  or public.can_read_department_member(id)
);

drop policy if exists attendance_self_read on public.attendance_records;
drop policy if exists attendance_read_scoped on public.attendance_records;
create policy attendance_read_scoped on public.attendance_records for select to authenticated using(
  user_id=auth.uid()
  or public.is_hr_admin()
  or public.can_read_department_member(user_id)
);
