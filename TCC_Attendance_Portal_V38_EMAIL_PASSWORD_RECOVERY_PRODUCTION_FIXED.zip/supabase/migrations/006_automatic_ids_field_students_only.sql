-- V36: automatic random IDs and Field Student-only member model
-- Student: STD/YYYY/XXXX
-- Admins (HR + Department): ADMN/YYYY/XXXX

alter table public.profiles drop constraint if exists profiles_category_check;
alter table public.profiles add constraint profiles_category_check check(category in('HR_ADMIN','DEPARTMENT_ADMIN','FIELD_STUDENT'));

-- Legacy STAFF accounts, if any, are converted to Field Students in this portal.
update public.profiles set category='FIELD_STUDENT' where category='STAFF';

create or replace function public.generate_profile_user_code(p_category text) returns text
language plpgsql security definer set search_path=public as $$
declare
  prefix text;
  candidate text;
begin
  if p_category='FIELD_STUDENT' then prefix:='STD';
  elsif p_category in('HR_ADMIN','DEPARTMENT_ADMIN') then prefix:='ADMN';
  else raise exception 'Unsupported profile category: %', p_category;
  end if;
  loop
    candidate:=prefix||'/'||to_char(current_date,'YYYY')||'/'||upper(substr(md5(gen_random_uuid()::text),1,4));
    exit when not exists(select 1 from public.profiles where user_code=candidate);
  end loop;
  return candidate;
end;
$$;

create or replace function public.assign_profile_user_code() returns trigger
language plpgsql security definer set search_path=public as $$
begin
  if new.category='FIELD_STUDENT' then
    if new.user_code is null or new.user_code !~ '^STD/[0-9]{4}/[A-Z0-9]{4}$' then
      new.user_code:=public.generate_profile_user_code('FIELD_STUDENT');
    end if;
  elsif new.category in('HR_ADMIN','DEPARTMENT_ADMIN') then
    if new.user_code is null or new.user_code !~ '^ADMN/[0-9]{4}/[A-Z0-9]{4}$' then
      new.user_code:=public.generate_profile_user_code(new.category);
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists profiles_auto_user_code on public.profiles;
create trigger profiles_auto_user_code before insert or update of category,user_code on public.profiles
for each row execute procedure public.assign_profile_user_code();

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path=public as $$
declare
  v_category text:=coalesce(new.raw_user_meta_data->>'category','FIELD_STUDENT');
  v_code text;
begin
  if v_category not in('HR_ADMIN','DEPARTMENT_ADMIN','FIELD_STUDENT') then v_category:='FIELD_STUDENT'; end if;
  v_code:=public.generate_profile_user_code(v_category);
  insert into public.profiles(id,full_name,official_email,phone,user_code,category,must_reset_password)
  values(new.id,coalesce(new.raw_user_meta_data->>'full_name',split_part(coalesce(new.email,''),'@',1)),new.email,new.raw_user_meta_data->>'phone',v_code,v_category,coalesce((new.raw_user_meta_data->>'must_reset_password')::boolean,false))
  on conflict(id) do nothing;
  return new;
end;
$$;

-- Give all existing accounts valid IDs according to their category.
update public.profiles set user_code=public.generate_profile_user_code(category)
where user_code is null
   or (category='FIELD_STUDENT' and user_code !~ '^STD/[0-9]{4}/[A-Z0-9]{4}$')
   or (category in('HR_ADMIN','DEPARTMENT_ADMIN') and user_code !~ '^ADMN/[0-9]{4}/[A-Z0-9]{4}$');

-- Prevent manually supplied IDs from using the wrong family.
alter table public.profiles drop constraint if exists profiles_user_code_format_check;
alter table public.profiles add constraint profiles_user_code_format_check check(
  (user_code is null) or
  (category='FIELD_STUDENT' and user_code ~ '^STD/[0-9]{4}/[A-Z0-9]{4}$') or
  (category in('HR_ADMIN','DEPARTMENT_ADMIN') and user_code ~ '^ADMN/[0-9]{4}/[A-Z0-9]{4}$')
);

comment on column public.profiles.user_code is 'Automatically generated: STD/YYYY/XXXX for Field Students; ADMN/YYYY/XXXX for administrators.';
