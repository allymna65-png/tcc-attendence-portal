-- TCC Attendance Portal V35: Department Admin leave visibility and management
-- Department Admins can read/update/delete leave requests only for their own department.

drop policy if exists leave_self_read on public.leave_requests;
drop policy if exists leave_admin_manage on public.leave_requests;

create policy leave_read_scoped on public.leave_requests
for select to authenticated
using (
  user_id=auth.uid()
  or public.is_hr_admin()
  or exists(
    select 1 from public.profiles target
    where target.id=leave_requests.user_id
      and target.department_id=public.current_department_id(auth.uid())
      and public.is_department_admin(auth.uid())
  )
);

create policy leave_admin_manage_scoped on public.leave_requests
for update,delete to authenticated
using (
  public.is_hr_admin()
  or exists(
    select 1 from public.profiles target
    where target.id=leave_requests.user_id
      and target.department_id=public.current_department_id(auth.uid())
      and public.is_department_admin(auth.uid())
  )
)
with check (
  public.is_hr_admin()
  or exists(
    select 1 from public.profiles target
    where target.id=leave_requests.user_id
      and target.department_id=public.current_department_id(auth.uid())
      and public.is_department_admin(auth.uid())
  )
);
