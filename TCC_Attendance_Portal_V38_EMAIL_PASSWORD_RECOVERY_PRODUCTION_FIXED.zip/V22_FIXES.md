# TCC Attendance Portal V22

## Fixes

- Removed the browser/device fingerprint block that could reject a legitimate user after switching between browser and installed PWA on the same phone.
- The fingerprint is still stored with attendance records for audit information, but it no longer prevents valid check-in or check-out.
- The 200m geofence remains the attendance boundary.
- The Tanzania local-date behavior from V21 is preserved.
- Today remains separate from historical attendance.
- Offline queue and synchronization behavior from V21 is preserved.
