# Responsive UI Update

- Reorganized admin header actions for desktop and mobile.
- Prevented Install App/Profile/Notifications/Role/Logout controls from wrapping into an uneven layout.
- Added compact mobile controls at very narrow widths.
- Centered/wrapped desktop navigation cleanly while retaining horizontal scrolling on small screens.
- Applied the same responsive header treatment to Field Student portal.
- No database, Supabase Edge Function, GPS, authentication, password-reset, or report logic changed in this UI-only update.
