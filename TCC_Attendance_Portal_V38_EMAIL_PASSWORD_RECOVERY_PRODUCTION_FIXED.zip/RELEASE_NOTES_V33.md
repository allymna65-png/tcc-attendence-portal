TCC Attendance Portal V33

This release fixes the department workflow and modernizes member editing.

Fixed:
- New members are persisted with department_id and department name.
- Department Admin creation uses the create_department_admin action.
- Member editing uses an in-app modern modal instead of browser prompt dialogs.
- Department registration duplicate errors are shown inside the modal instead of behind it.
- Department Admin registration errors are shown inside the modal.
- Global success messages use a non-blocking toast.
- Admin header includes a notification bell with unread count.
- PWA cache version is bumped to force fresh frontend assets.
- JSX syntax was statically validated across client/src with zero diagnostics.

Supabase:
- The V32 database repair SQL was already intended for the existing project.
- Edge Functions in supabase/functions must match this release, especially admin-users and leave-request.
