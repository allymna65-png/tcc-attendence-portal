# Password Reset Repair

- Prevented duplicate forgot-password submissions in the UI.
- Removed the stale hard-coded Vercel reset URL.
- Recovery redirects now use the current deployed/local origin.
- Added user-friendly handling for Supabase 429/rate-limit errors.
- No database schema or existing admin/approval reset flow was removed.
