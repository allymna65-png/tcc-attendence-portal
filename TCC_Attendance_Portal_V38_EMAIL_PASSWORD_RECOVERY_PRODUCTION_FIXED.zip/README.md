# TCC Attendance Portal V35 FINAL PRODUCTION

V35 FINAL PRODUCTION adds reliable Sign In and Sign Out state handling and a persistent user notification center.

## Sign In / Sign Out
- A user can Sign In only once per Tanzania local day.
- Sign In becomes disabled immediately after a successful or queued Sign In.
- Sign Out is available only after Sign In.
- Sign Out becomes disabled immediately after a successful or queued Sign Out.
- The backend also enforces one Sign In and one Sign Out per day.
- Out-of-bounds attempts show a clear message and do not create an attendance record.
- Browser/device fingerprint is stored for audit only and is not used to block attendance.

## Notifications
Users have a notification center for:
- Successful Sign In.
- Successful Sign Out.
- Approved leave.
- Rejected leave.
- HR-approved password reset.

Notifications can be marked individually or all at once.

## Deployment
Apply all Supabase migrations, including `002_notifications.sql`, then deploy the updated Edge Functions and frontend.


V32 database repair: run `supabase/migrations/004_complete_department_notification_repair.sql` once if the database reports missing `profiles.department_id` or `public.departments`. Deploy the `leave-request` and `password-reset-request` Edge Functions so management admins receive request notifications.


## Automatic IDs
Field Student IDs use `STD/YYYY/XXXX`; administrator IDs use `ADMN/YYYY/XXXX`. The four-character suffix is random/non-sequential.
