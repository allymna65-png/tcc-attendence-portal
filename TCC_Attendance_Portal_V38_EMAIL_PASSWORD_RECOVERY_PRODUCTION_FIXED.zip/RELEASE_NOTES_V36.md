# TCC Attendance Portal V36

- Field Student-only member portal; Staff category removed.
- Student IDs generated automatically as `STD/YYYY/XXXX`.
- HR Admin and Department Admin IDs generated automatically as `ADMN/YYYY/XXXX`.
- `XXXX` is random and non-sequential.
- Manual ID/category entry is removed from onboarding and import.
