# V36 Login Security Fix

- Removed the login-page text: "No public sign-up. Use your official email or Student/Admin ID."
- Removed "HR Management Portal" branding from the login shell.
- Supabase auth now uses `sessionStorage` instead of persistent local storage.
- A page reload keeps the active session, but closing the browser/app tab ends the session and the next launch requires login again.
- Existing Supabase Edge Functions were not modified by this frontend-only patch.
