# V38 Password Reset Production Fix

- Forgot Password always sends Supabase recovery emails with the production redirect:
  https://tccattendanceportalv37emailpassword-tan.vercel.app/reset-password
- Service worker moved to `/sw-v38.js` and no longer caches HTML/JavaScript.
- Legacy `/sw.js` is network-only and no-cache.
- Vercel headers disable caching for service-worker files and index.html.
- No HR approval/reset-queue flow was introduced.
