# TCC Attendance Portal — Email Password Recovery

The portal now uses Supabase email recovery instead of the HR Reset Queue.

## 1. Supabase Auth URL Configuration
In Supabase Dashboard → Authentication → URL Configuration:
- **Site URL:** your production Vercel URL (for example `https://YOUR-PRODUCTION-DOMAIN.vercel.app`)
- **Redirect URLs:** add the exact production reset page: `https://YOUR-PRODUCTION-DOMAIN.vercel.app/reset-password`
- For local development, also add: `http://localhost:5173/reset-password`
- If you use Vercel preview deployments, add an appropriate preview wildcard only if your Supabase URL configuration policy allows it.

The app now builds the recovery redirect from the current site origin, so production links return to the deployed site and local development links return to the local site.

## 2. Email delivery
For production use, configure a reliable SMTP provider in Supabase Auth. The built-in Supabase email service is intended for development/testing and is rate-limited.

## 3. Account creation
Official email is required for:
- Primary HR Admin setup
- Department Admin creation
- Field Student creation
- Bulk import
- Member editing

The backend validates email format and the Auth service enforces email uniqueness.

## 4. Recovery flow
1. User taps **Forgot Password?**.
2. User enters official email.
3. Supabase sends a recovery email.
4. The link opens `/reset-password`.
5. User enters and confirms a new password.
6. The portal updates the Auth password and clears `must_reset_password` when applicable.

The forgot-password response intentionally does not reveal whether an email exists.

## 5. Database migration
Run `supabase/migrations/008_mandatory_official_email.sql` in Supabase SQL Editor. It first backfills missing profile emails from `auth.users`, then makes `profiles.official_email` NOT NULL.


## Production reset redirect
Password recovery uses the current site origin. Add the production `/reset-password` URL and your local `/reset-password` URL to Supabase Authentication → URL Configuration → Redirect URLs.
