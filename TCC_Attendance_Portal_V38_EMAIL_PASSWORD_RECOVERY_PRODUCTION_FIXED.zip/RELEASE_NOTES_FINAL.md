# TCC Attendance Portal V36 – Final Consolidated Fixes

Included in this package:
- Robust Android/iPhone GPS acquisition for attendance and Use Current Device Location.
- 500m Sign In geofence and 600m Sign Out geofence (100m checkout tolerance).
- Mandatory password reset flow and complete_password_reset(uid) compatibility migration.
- Department Admin default password ADMN_123456.
- Login session uses browser/app sessionStorage so a fresh browser/app session requires login again.
- Removed login subtitle “No public sign-up…” and removed “HR Management Portal”.
- Password Reset Queue Approve & Reset frontend handler fixed for production build.
- Password reset approval Edge Function performs actual Auth password reset, marks must_reset_password=true, approves the request, and notifies the user.
- iPhone-friendly report printing without relying on window.open popup.
- Report layout redesigned for A4 landscape with centered logo and headings:
  PRIME MINISTER OFFICE REGIONAL ADMINISTRATION AND LOCAL GOVERNMENT
  TANGA CITY COUNCIL
  TCC ATTENDANCE REPORT
  Date: [selected date]
- Larger, readable report table typography, alternating row shading, formal header/footer.
